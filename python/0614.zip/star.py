'''
a = print("*****")
b = print(" ****")
c = print("  ***")
d = print("   **")
e = print("    *")
'''


'''
b = print("a")
print(print(b))
'''
'''
a = "*"
b = " "
c1 = (b*0)+(a*5)
c2 = (b*1)+(a*4)
c3 = (b*2)+(a*3)
c4 = (b*3)+(a*2)
c5 = (b*4)+(a*1)

print(c1)
print(c2)
print(c3)
print(c4)
print(c5)
'''
'''
a = "*"
b = " "

c1 = (b*0)+(a*5)
c2 = (b*1)+(a*4)
c3 = (b*2)+(a*3)
c4 = (b*3)+(a*2)
c5 = (b*4)+(a*1)

print(c1)
print(c2)
print(c3)
print(c4)
print(c5)
'''
'''
x = "c"
for y in range(5):
    print(x,y)

x1 = "b"
for y1 in range(5):
    print(x1,y1)

x2 = "a"
for y2 in range(5):
    print(x2,y2)
'''



'''
b = "c"*5
print(b)

for y in range(5):
    print(x,y)
'''
'''
a = "*"
b = " "

c1 = (b*0)+(a*5)
c2 = (b*1)+(a*4)
c3 = (b*2)+(a*3)
c4 = (b*3)+(a*2)
c5 = (b*4)+(a*1)

print(c1)
print(c2)
print(c3)
print(c4)
print(c5)
'''
'''
for i in range(5):
    for j in range(5):
        for j in range(i):
            print(' ', end='')
        for k in range(j):
            print('*', end='')
        print()
'''
'''
for i in range(5):
    for j in range(0,5):
        print(' ', end='')
    for k in range(5,0):
        print('*', end='')
    print()
'''
'''
a=int(input())
for i in range(1,a+1):
    print(" "*(i-1) + "*"*(a-i+1))
'''

for i in range(1,6):
    print(" " * (i-1) + "*" * (6-i))
