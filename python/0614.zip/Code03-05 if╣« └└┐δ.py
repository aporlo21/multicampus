import random
'''
numbers = []
for _ in range(0,10) : # for ( i=0; i<10; i++ )
    numbers.append(random.randint(0,9))

print(numbers)

for num in range(0,10) :
    if num not in numbers :
        print(num, '없어요')
'''
'''
numbers = []
for x in range(0,10):
    numbers.append(random.randint(0,9))
print(numbers)
'''
a = []
for x in range(0,5):
    a.append(random.randint(0,5))
print(a)