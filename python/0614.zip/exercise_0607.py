bin(11); bin(0o11); bin(0x11) #2진수
oct(11); oct(0b11); oct(0x11) #8진수
hex(11); hex(0b11); hex(0o11) #16진수
print(bin(0x11))

