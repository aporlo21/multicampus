def hap():
    n1 = int(input("num1:"))
    n2 = int(input("num2:"))
    hap = n1 + n2
    print(hap)

def sub():
    n1 = int(input("num1:"))
    n2 = int(input("num2:"))
    sub = n1 - n2
    print(sub)

def mult():
    n1 = int(input("num1:"))
    n2 = int(input("num2:"))
    gob = n1 * n2
    print(gob)

def dev():
    n1 = int(input("num1:"))
    n2 = int(input("num2:"))
    dev = n1 / n2
    print(dev)


while True:
    print(" menu ")
    print(" ---- ")
    print(" 1: hap ")
    print(" 2: sub ")
    print(" 3: gob ")
    print(" 4: dev ")
    print(" 5: stop ")

    b1 = int(input(":"))
    if(b1 == 1) : hap();
    elif(b1 == 2) : sub();
    elif (b1 == 3) : mult();
    elif (b1 == 4) : dev();
    elif (b1 == 5) : break

    else : print("u got a wrong num")