'''
for x in range(1,10):
    for y in range(1, 10):
        print(x,"*",y,"=",x*y,end="\n")
    print()
'''
    # 입력받아서 해당 구구단 실행

