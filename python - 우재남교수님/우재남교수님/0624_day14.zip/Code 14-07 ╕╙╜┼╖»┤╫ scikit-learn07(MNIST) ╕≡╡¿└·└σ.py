from sklearn import svm, metrics ## and gate 훈련시키고 결과 보기
import pandas as pd
from sklearn.model_selection import train_test_split
import math

def changeValue(list) :
    return [ float(v) / 255 for v in list ]
#    return [math.ceil(float(v) / 255) for v in list] # 이진화 |
# 붓꽃 데이터 분류기 ( 머신러닝 )
# - 개요 : 150 개 붓꽃 정보 (꽃받침 길이, 꽃받침 폭, 꽃잎 길이, 꽃잎 폭)
# - 종류 : 3개 (Iris-setosa, Iris-vesicolor, Iris-virginica)
# - csv 파일 : 검색 iris.csv
# 0. 훈련데이터, 테스트 데이터 준비
# csv = pd.read_csv('c:/BigData/mnist/train_5K.csv')
# train_data = csv.iloc[:, 1:].values
# train_data = list(map(changeValue, train_data))
# train_label = csv.iloc[:, 0].values
csv = pd.read_csv('c:/BigData/mnist/t10k_0.5K.csv')
test_data = csv.iloc[:, 1:].values
test_data = list(map(changeValue, test_data))
test_label = csv.iloc[:, 0].values

# 학습용, 훈련용 분리

# # 1. Classifire 생성 (선택) ==> 머신러닝 알고리즘 선택
# clf = svm.SVC(gamma='auto') #--> error 없애
#
# # 2. 데이터로 학습시키기
# # clf.fit([훈련데이터], [정답]) XOR 개념
# clf.fit( train_data,train_label )

import joblib
# 학습된 모델 저장하기 (파이썬 에서만)
clf = joblib.load('mnist_model_1k.dmp')
#joblib.dump(clf,'mnist_model_1k.dmp')

print('저장, OK')
# 3. 정답률을 확인 (신뢰도)
result = clf.predict(test_data)
score = metrics.accuracy_score(result, test_label)
print("정답률 :", "{0:.2f}%".format(score*100))

# 그림 사진 보기
# import matplotlib.pyplot as plt
# import numpy as np
# img = np.array(test_data[0]).reshape(28,28)
# plt.imshow(img, cmap = 'gray')
#
#
# # # 3. 예측하기
# # # clf.predict( [ 예측할 데이터 ] )
# result = clf.predict( [[4.1, 3.3, 1.5, 0.2]] ) # test data
# print(result)