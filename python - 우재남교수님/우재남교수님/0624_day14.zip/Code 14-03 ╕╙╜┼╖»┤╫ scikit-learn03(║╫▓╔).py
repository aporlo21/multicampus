from sklearn import svm, metrics ## and gate 훈련시키고 결과 보기
import pandas as pd
# 붓꽃 데이터 분류기 ( 머신러닝 )
# - 개요 : 150 개 붓꽃 정보 (꽃받침 길이, 꽃받침 폭, 꽃잎 길이, 꽃잎 폭)
# - 종류 : 3개 (Iris-setosa, Iris-vesicolor, Iris-virginica)
# - csv 파일 : 검색 iris.csv

csv = pd.read_csv('c:/Bigdata/iris.csv')
train_data = csv.iloc[0:120, 0:-1]
train_label = csv.iloc[0:120, [-1]]
test_data = csv.iloc[120:, 0:-1]
test_label = csv.iloc[120:, [-1]]


# 1. Classifire 생성 (선택) ==> 머신러닝 알고리즘 선택
clf = svm.NuSVC(gamma='auto') #--> error 없애

# 2. 데이터로 학습시키기
# clf.fit([훈련데이터], [정답]) XOR 개념
clf.fit( train_data,train_label )
# 3. 정답률을 확인 (신뢰도)
result = clf.predict(test_data)
score = metrics.accuracy_score(result, test_label)
print("정답률 :", "{0:.2f}%".format(score*100))

# # 3. 예측하기
# # clf.predict( [ 예측할 데이터 ] )
result = clf.predict( [[4.1, 3.3, 1.5, 0.2]] ) # test data
print(result)