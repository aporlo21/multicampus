from sklearn import svm
# 1. Classifire 생성 (선택) ==> 머신러닝 알고리즘 선택
clf = svm.SVC(gamma='auto') #--> error 없애

# 2. 데이터로 학습시키기
# clf.fit([훈련데이터], [정답]) XOR 개념
clf.fit( [[0,0],
          [0,1],
          [1,0],
          [1,1]],
         [ 0, 1, 1, 0])
# 예측하기
# clf.predict( [ 예측할 데이터 ] )
result = clf.predict( [ [1, 0] ])

print(result)
