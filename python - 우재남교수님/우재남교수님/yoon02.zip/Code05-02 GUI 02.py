from tkinter import *
from tkinter import messagebox
def clickButton() :
    messagebox.showinfo('요기제목', '요기내용')

window = Tk() # root = Tk()

label1 = Label(window, text = "파이썬 공부중~~" )
label2 = Label(window, text = "파이썬 공부중~~", font=("궁서체", 30), fg = "blue")
label3 = Label(window, text = "파이썬 ", bg = "red", width=20, height=5, anchor = SE)

photo = PhotoImage(file='C:\images\Pet_GIF\Pet_GIF(256x256)/cat01_256.gif')
label4 = Label(window, image = photo)
button1 = Button(window, text = '나를 눌러줘', command = clickButton ) # 함수의 시작은 소문자, 동사형으로 상용
button2 = Button(window, image = photo, command = clickButton ) # 함수의 시작은 소문자, 동사형으로 상용

label1.pack(side = LEFT)
label2.pack()
label3.pack()
label4.pack() # 빈 레이블에 내용붙이기
button1.pack()
button2.pack(side = RIGHT)
window.mainloop()
#위젯이름=tkinter.Label(윈도우창, text="내용")을 사용하여 윈도우 창에 Label 위젯을 설정할 수 있습니다.
#위젯이름.pack()을 사용하여 위젯을 배치할 수 있습니다.
