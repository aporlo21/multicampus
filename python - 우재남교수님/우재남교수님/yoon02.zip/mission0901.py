## 트리뷰 활용
from tkinter import *
from tkinter import ttk

window = Tk()
window.geometry('800x500')
sheet = ttk.Treeview(window)
# 첫번째 열 헤더 만들기
sheet.column('#0', width=70) # 첫 컬럼의 내부이름
sheet.heading('#0', text='제목')
# 두번째 이후 열 헤더 만들기
sheet['columns'] = ("A", "B", "C") # 두분째 이후 컬럼의 내부이름(내맘대로)
sheet.column("A", width=70); sheet.heading('A', text='ROW')
sheet.column("B", width=70); sheet.heading('B', text='COLUMN')
sheet.column("C", width=70); sheet.heading('C', text='VALUE')
# 내용 채우기.
sheet.insert('', 'end', text=' ', values=('0', '0', '123'))
sheet.insert('', 'end', text=' ', values=('0', '1', '111'))
sheet.insert('', 'end', text=' ', values=('511', '511', '99'))

sheet.pack()
window.mainloop()