# # 메모리를 할당해서 리스트(참조)를 반환하는 함수
# def malloc(h, w) :
#     retMemory= []
#     for _ in range(h) :
#         tmpList = []
#         for _ in range(w) :
#             tmpList.append(0)
#         retMemory.append(tmpList)
#     return retMemory
#
#   h,w 인자(파라미터) 를 가지는 malloc함수 정의 // retMemory라는 빈공간 리스트를 지정해준다 // h 범위내에서 _ 번 반복하는 for 반복문에 넣는다 //
#   tmpList라는 변수에 빈공간 리스트를 지정해준다 // w 범위내에서 _ 번 반복하는 for 반복문에 넣는다 // tmpList 빈 리스트 뒤에 0원소를 기입한다 //
#   for - w에 관한 반복이 끝나면 retmemory 리스트 뒤에 tmplist 요소를 덧붙인다 // for - h 에 관한 반복문이 끝이나면 retMemory 값을 반환한다
#
# # 파일을 메모리로 로딩하는 함수
# def loadImage(fname) :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     fsize = os.path.getsize(fname) # 파일의 크기(바이트) # os.path.getsize = 파일의 크기 반환
#     inH = inW = int(math.sqrt(fsize)) # 핵심 코드
#     ## 입력영상 메모리 확보 ##
#     inImage=[]
#     inImage=malloc(inH,inW)
#     # 파일 --> 메모리
#     with open(filename, 'rb') as rFp:
#         for i in range(inH) :
#             for k in range(inW) :
#                 inImage[i][k] = int(ord(rFp.read(1)))
#
#   전역변수 불러온다 // 파일의 크기를 반환하는 os.path.getsize (운영체제 기능 반환/파일 경로반환,수정,생성) // inH, inW 는 파일크기를 루트로 반환 하는 정수값들
#   inImage 변수 내에 빈리스트 확보하고 inH,inW로 대변되는 반환되는 파일 크기 루트값을 malloc함수내 인자로 받는다 // open()함수로 파일을 열고
#   리턴되는 디스크립터를 rFp라는 이름에 바인딩(속성에 연관시킨다)한다 // 이후 들여쓴 블럭 내에서 rFp는 파일 핸들러 기능을 한다
#   open함수내에 read / write / close 기능이 자동 내장되어 있다. <= with구문에 사용될수 있는 객체
#
#
# # 파일을 선택해서 메모리로 로딩하는 함수
# def openImage() :
#     global window, canvas, paper, filename, inImage, outImage,inH, inW, outH, outW
#     filename = askopenfilename(parent=window,
#                 filetypes=(("RAW 파일", "*.raw"), ("모든 파일", "*.*")))
#     loadImage(filename)
#     equalImage()
#


# def displayImage() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     if canvas != None : # 예전에 실행한 적이 있다.
#         canvas.destroy()
#     ## 화면 크기를 조절
#     window.geometry(str(outH) + 'x' + str(outW)) # 벽
#     canvas = Canvas(window, height=outH, width=outW) # 보드
#     paper = PhotoImage(height=outH, width=outW) # 빈 종이
#     canvas.create_image((outH//2, outW//2), image=paper, state='normal')
#     ## 출력영상 --> 화면에 한점씩 찍자.
#     for i in range(outH) :
#         for k in range(outW) :
#             r = g = b = outImage[i][k]
#             paper.put("#%02x%02x%02x" % (r, g, b), (k, i))
#
#     canvas.pack(expand=1, anchor=CENTER)
#
#
#
#
# # 동일영상 알고리즘
# def  equalImage() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;  outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];    outImage = malloc(outH, outW)
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     for i in range(inH) :
#         for k in range(inW) :
#             outImage[i][k] = inImage[i][k]
#
#     displayImage()

inImage, outImage = [], []
inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""

###################################################################################
###################################################################################
###################################################################################
# window=tkinter.Tk() => 윈도우이름=tkinter.Tk()를 이용하여 가장 상위 레벨의 윈도우 창을 생성할 수 있습니다.
from tkinter import * # tkinter는 GUI에 대한 표준 Python 인터페이스이며 Window 창을 생성할 수 있습니다.
from tkinter.simpledialog import * # askinteger(), askstring(), askfloat() 함수를 사용할 때 임포트해야 하는 모듈 / 기본 대화 상자와 편리 함수.
from tkinter.filedialog import * # 사용자가 열거나 저장할 파일을 지정할 수 있도록 하는 일반 대화 상자입니다.
import math # 좀더 복잡한 연산 필요시 math 모듈
import os # Operating System의 약자로서 운영체제에서 제공되는 여러 기능을 파이썬에서 수행할 수 있게 해준다.
import os.path #  os.path는 파일 경로를 생성 및 수정하고, 파일 정보를 쉽게 다룰 수 있게 해주는 모듈.

# os.path.exists는 입력받은 경로가 존재하면 True를 반환하고, 존재하지 않는 경우는 False를 반환 => 파일이 없을때 오류를 방지하는 함수 # 파일여부확인
# askinteger() 함수에서 입력값의 범위를 제한할 때 사용하는 항목 = minvalue, maxvalue

# 함수 선언부
# memory allocation 메모리 할당

def malloc(): # 메모리를 할당해서 리스트를 반환하는 함수
    pass

def openImage():
    loadImage()
    equalImage()
    pass

# inImage 생성
def loadImage():
    malloc()
    pass

# outImage 생성
def equalImage():
    malloc()
    displayImage()
    pass

def displayImage():
    pass

# 생성 구문과 반복 구문 사이에 위젯을 생성하고 적용합니다.
# 메인코드부
window = Tk() # tkinter.Tk()를 적용할 경우 가장 기본적인 윈도우 창이 생성됩니다.
window.geometry("500x500") # 윈도우이름.geometry("너비x높이+x좌표+y좌표") 초기 화면 위치의 x좌표와 y좌표를 설정
window.title("컴퓨터 비전(딥러닝 기법) ver 0.01")

mainMenu = Menu(window) # 해당 메뉴창에 표시할 상위 메뉴의 속성을 설정할 수 있습니다. 파라미터를 사용하여 상위 메뉴의 속성을 설정합니다.
window.config(menu=mainMenu) # 윈도우 창.config(menu=메뉴 이름)을 통하여 해당 윈도우 창에 메뉴를 등록할 수 있습니다.

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImage)
# add_cascade(파라미터)	상위 메뉴와 하위 메뉴 연결
# add_separator()	구분선 생성
window.mainloop() # 윈도우이름.mainloop()를 사용하여 윈도우이름의 윈도우 창을 윈도우가 종료될 때 까지 실행시킵니다. # 이벤트 처리를 위해

# tk() : 기본적 윈도우창 생성 // .geometry() : 초기화면 면적, 좌표설정 // .title : 제목설정
# menu() : 상위메뉴 속성설정 // .config(menu = mainMenu) : 윈도우 창을 통해 해당 윈도우창에 메뉴 등록
# .add_cascade() : 파일메뉴에 '파일'위젯을 생성 // .add_command() : '파일열기' 위젯을 생성하고 openimage() 함수 명령 수행

#지역변수 & 전역변수
# 함수의 지역변수는 함수가 실행되는 동안에만 존재한다. 각 함수가 호출되어 실행될 때 만들어지고, 함수의 실행이 끝나면 모두 삭제된다.
# 그래서 지역변수는 그 변수가 속한 함수의 밖이나 다른 함수에서는 부를 수 없다. 매개변수도 함수 안에 정의되므로 지역변수다

# 위 코드는 파일을 입력할때 한번에 파일 한개만 선택이 가능하다.
# 한번에 2~3개 다수의 파일을 획득하려면
# askopenfilename 부분을 askopenfilenames 변경해주면 된다

# ① 없는 변수에 접근할 때 = NameError
# ② 파일 처리에서 오류가 발생할 때 = IOError
# ③ 실행에서 오류가 발생할 때 = RuntimeError
# ④ 딕셔너리에 키가 없을 때 = KeyError
# SyntaxError = exec()나 eval()에서 문법상 오류가 발생할 때

# 함수의 정의 자체는 반환값이 1개여야 하지만 리스트나 튜플로 여러 개의 값을 반환할 수 있다.
# aoa[1::3]    # 1번 index부터 끝까지 index를 3씩 증가해서 list로 접근
# sort() -> 리스트의 항목을 정렬한다.(default로 오름차순 정렬)
# () [] : 비어있는 자료구조를 초기화시켜줌
# callback() : 경로를 잡기위한 함수