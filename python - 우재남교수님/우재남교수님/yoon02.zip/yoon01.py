# 버튼단추
from tkinter import *
from tkinter import messagebox # tkinter.messagebox : 표준 Tk 대화 상자에 액세스합니다.
from tkinter.filedialog import *
from tkinter.simpledialog import *

def clickButton1() :
    messagebox.showinfo('버튼1','윤기')
def clickButton2() :
    messagebox.showinfo('버튼2','호진')
def clickButton3() :
    messagebox.showinfo('image','아무거나')
################ 메인코드부 ####################
window = Tk() # root = Tk()
window.geometry("600x500")
window.title("컴퓨터 비전(딥러닝 기법) ver 0.00000001")

label1 = Label(window, text = "'hello'" )

photo = PhotoImage(file='C:\images\Pet_GIF\Pet_GIF(256x256)/cat01_256.gif')
label2 = Label(window, image = photo)
button1 = Button(window, text = '버튼1', command = clickButton1 ) # 함수의 시작은 소문자, 동사형으로 상용
button2 = Button(window, text = '버튼2', command = clickButton2 )
button3 = Button(window, image = photo, command = clickButton3 )

label1.pack(anchor = NW)

button1.place(x=350, y=30 )
button2.place(x=450, y=30)
button3.pack(anchor = W)  # anchor	메뉴버튼안의 문자열 또는 이미지의 위치

txtPanel = Text(window, height=10, width=20, bg='yellow')
txtPanel.pack(expand=1, anchor = SW)


############################ 마우스이벤트 ################################
mainMenu = Menu(window)
window.config(menu=mainMenu)

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="호진", menu=fileMenu)
fileMenu.add_command(label="바보")

comVisionMenu1 = Menu(mainMenu)
mainMenu.add_cascade(label="윤기", menu=comVisionMenu1)
comVisionMenu1.add_command(label="천재")

comVisionMenu2 = Menu(mainMenu)
mainMenu.add_cascade(label="태형", menu=comVisionMenu2)
comVisionMenu2.add_command(label="개천재")

window.mainloop()
