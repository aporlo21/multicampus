hap = 0
for i in range(12345,100001,1) : # range(0,101), range(101)
    if i % 7878 == 0 :
        hap += i
print(hap)

