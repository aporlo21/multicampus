import random

## 초기 배열
a = [ random.randint(0,30) for _ in range(10)]
print(a)

## Selection Sort
## To do...

#
# for i in range(10):
#     for k in range(10):
#         if(a[k] < a[len(a)-i]):
#             print(a)


#
# if(a[i] < a[0,(len(a)-1)]): print(a)
#
for k in range(len(a)):
    for i in range(len(a)-k):
        if(a[k] > a[len(a)-1-i]):
            a[k],a[len(a)-1-i] = a[len(a)-1-i],a[k]
print(a)
#
# if a[0] > a[1]:
#     a[0], a[1] = a[0]
#

## 정렬된 배열
# print(a)