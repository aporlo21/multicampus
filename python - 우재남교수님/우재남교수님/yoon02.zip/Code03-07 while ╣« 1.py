"""
hap = 0
# for i in range(101) :
#    hap += i

i = 0
while i < 101 :
    hap += i
    i += 1
print(hap)

#while : 무한반복
"""

hap = 0
i = 0
while True :
    hap += i
    i += 1

    if hap > 10000 :
        break

print(hap)

'''
i = 1
sum = 1
while True:
    i += 1
    sum += 1
    if(sum>101): break

print(sum)
'''

'''
sum = 0
i = 0
while i < 101 :
    sum += i
    i += 1
print(sum)
'''
'''
sum = 0
i = 0
while(i < 101):
    sum += i
    i += 1
print(sum)
'''