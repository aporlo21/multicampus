while(True):
    x = int(input("값을 입력하시오 : "))
    if (x >= 10): print("u got out of the range")
    elif (x <= 0) : print("u got out of the range")
    elif (0 < x < 10):
        for y in range(1, 10):
            print(x, "*", y, " =", x * y)
        print()