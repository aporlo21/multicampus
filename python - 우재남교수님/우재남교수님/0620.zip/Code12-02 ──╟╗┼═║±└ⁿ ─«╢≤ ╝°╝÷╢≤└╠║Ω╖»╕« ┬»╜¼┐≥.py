from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps

####################
#### 전역변수 선언부 ####
####################
inImage, outImage = [], [] ; inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""
panYN = False
sx,sy,ex,ey = [0] * 4
VIEW_X, VIEW_Y = 512, 512 # 화면에 보일 크기 (출력용)

####################
#### 메인 코드부 ####
####################
window = Tk()
window.geometry("500x500")
window.title("컴퓨터 비전(딥러닝 기법) ver 0.08")

status = Label(window, text='이미지 정보:', bd=1, relief=SUNKEN, anchor=W)
status.pack(side=BOTTOM, fill=X)

# 메모리를 할당해서 리스트(참조)를 반환하는 함수
def malloc(h, w, initValue=0) :
    retMemory= []
    for _ in range(h) :
        tmpList = []
        for _ in range(w) :
            tmpList.append(initValue)
        retMemory.append(tmpList)
    return retMemory

# 파일을 선택해서 메모리로 로딩하는 함수
import time
def openImagePIL() :
    global window, canvas, paper, filename, inImage, outImage,inH, inW, outH, outW
    filename = askopenfilename(parent=window,
                filetypes=(("칼라파일", "*.jpg", "*.png", "*.tif", "*.bmp"), ("모든 파일", "*.*")))  ## 칼라데이터는 jpg 등등 해당 파일형식으로 불러옴 gif는 제외 주로
    if filename == '' or filename == None :
        return
    inImage = Image.open(filename)
    inW = inImage.width
    inH = inImage.height

    outImage = inImage.copy()
    outW = outImage.width
    outH = outImage.height

    displayImagePIL()

def displayImagePIL() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    if canvas != None : # 예전에 실행한 적이 있다.
        canvas.destroy()
    VIEW_X = outW
    VIEW_Y = outH

    window.geometry(str(int(VIEW_Y*1.2)) + 'x' + str(int(VIEW_X*1.2)))  # 벽
    canvas = Canvas(window, height=VIEW_Y, width=VIEW_X)
    paper = PhotoImage(height=VIEW_Y, width=VIEW_X)
    canvas.create_image((VIEW_Y // 2, VIEW_X // 2), image=paper, state='normal')

    import numpy
    rgbImage = outImage.convert('RGB')
    rgbStr = '' # 전체 픽셀의 문자열을 저장
    for i in numpy.arange(0,outH, step) :
        tmpStr = ''
        for k in numpy.arange(0,outW, step) :
            i = int(i); k = int(k)
            r, g, b = rgbImage.getpixel((k,i))
            tmpStr += ' #%02x%02x%02x' % (r,g,b)
        rgbStr += '{' + tmpStr + '} '
    paper.put(rgbStr)

    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='이미지 정보:' + str(outW) + 'x' + str(outH))

# 파일을 메모리로 로딩하는 함수
def loadImage(fname) :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    fsize = os.path.getsize(fname) # 파일의 크기(바이트)
    inH = inW = int(math.sqrt(fsize)) # 핵심 코드
    ## 입력영상 메모리 확보 ##
    inImage=[]
    inImage=malloc(inH,inW)
    # 파일 --> 메모리
    with open(fname, 'rb') as rFp:
        for i in range(inH) :
            for k in range(inW) :
                inImage[i][k] = int(ord(rFp.read(1)))

def mallocPIL():
    pass
def addImagePIL() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    value = askfloat("밝게/어둡게", "값(0~16)-->", minvalue=0.0, maxvalue=16.0)
    outImage = inImage.copy()
    outImage = ImageEnhance.Brightness(outImage).enhance(value)
    outW = outImage.width
    outH = outImage.height
    displayImagePIL()

def saveImagePIL() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    if outImage == None :
        return
    saveFp = asksaveasfile(parent=window, mode='wb',
        defaultextension='*.jpg', filetypes=(("JPG 파일", "*.jpg"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None :
        return
    outImage.save(saveFp.name)
    print('Save~')

def blurImagePIL() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    outImage = inImage.copy()
    outImage = outImage,filter(ImageFilter.BLUR)
    outW = outImage.width
    outH = outImage.height
    displayImagePIL()

def zooominImagePIL() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("확대", "값(2~8)-->", minvalue=0.0, maxvalue=16.0)
    outImage = inImage.copy()
    outImage = outImage.resize((inH*scale, inW*scale))
    outW = outImage.width
    outH = outImage.height
    displayImagePIL()


## 마우스 이벤트
mainMenu = Menu(window)
window.config(menu=mainMenu)


fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImagePIL)
fileMenu.add_separator()
fileMenu.add_command(label="파일 저장", command=saveImagePIL)

comVisionMenu1 = Menu(mainMenu)
mainMenu.add_cascade(label="화소점 처리", menu=comVisionMenu1)
comVisionMenu1.add_command(label="덧셈/뺄셈", command=addImagePIL)

comVisionMenu2 = Menu(mainMenu)
mainMenu.add_cascade(label="화소영역처리", menu=comVisionMenu2)
comVisionMenu1.add_command(label="블러링", command=blurImagePIL)

comVisionMenu3 = Menu(mainMenu)
mainMenu.add_cascade(label="기하학적처리", menu=comVisionMenu3)
comVisionMenu1.add_command(label="줌인", command=zooominImagePIL)

window.mainloop()

