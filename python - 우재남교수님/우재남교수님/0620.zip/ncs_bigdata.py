from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path


inImage, outImage = [], []
inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""


# 파일을 선택해서 메모리로 로딩하는 함수
def openImage() :
    global window, canvas, paper,\
        filename, inImage, outImage, inH, inW, outH, outW
    filename = askopenfilename(parent = window,
                               filetypes = ((" RAW파일", "*.raw"), ("모든 파일", "*.*")))
    loadImage(filename)
    equalImage()

# 파일을 메모리로 로딩하는 함수
def loadImage(fname) :

    global window, canvas, paper,\
        filename, inImage, outImage, inH, inW, outH, outW
    fsize = os.path.getsize(fname)
    inH = inW = int(math.sqrt(fsize))

    ## 입력영상 메모리 확보
    inImage = []
    inImage = malloc(inH, inW)

    ## 파일 ==> 메모리
    with open(filename, 'rb') as rFp :
        for i in range(inH) :
            for k in range(inW) :
                inImage[i][k] = int(ord(rFp.read(1)))

# ord : 하나의 유니코드 문자를 나타내는 문자열이 주어지면 해당 문자의 유니코드 코드 포인트를 나타내는 정수를 돌려줌
# open()함수로 파일을 열고
# 리턴되는 디스크립터를 rFp라는 이름에 바인딩(속성에 연관시킨다)한다 // 이후 들여쓴 블럭 내에서 rFp는 파일 핸들러 기능을 한다
# open함수내에 read / write / close 기능이 자동 내장되어 있다. <= with구문에 사용될수 있는 객체

# 메모리 할당해서 리스트를 반환하는 함수
def malloc(Height, Width) :

    retMemory = []
    for i in range(Height) :
        tmpList = []
        for k in range(Width) :
            tmpList.append(0)
        retMemory.append(tmpList)
    return retMemory

def equalImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드, 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = malloc(outH, outW)
    ## 컴퓨터 비전 알고리즘 ##
    for i in range(outH) :
        for k in range(outW) :
            outImage[i][k] = inImage[i][k]
    display()


def display() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    if canvas != None :
        canvas.destroy()
    ## 화면 크기를 조절
    window.geometry(str(outH) + 'x' + str(outW))
    canvas = Canvas(window, height=outH, width=outW)
    paper = PhotoImage(height=outH, width=outW)
    canvas.create_image((outH//2, outW//2), image=paper, state='normal')
    ## 출력영상 ==> 화면에 한점씩 찍자.
    for i in range(outH) :
        for k in range(outW) :
            r = g = b = outImage[i][k]
            paper.put("#%02x%02x%02x" % (r, g, b), (k, i))
    canvas.pack(expand = 1, anchor = CENTER)

def  revImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;  outW = inW;
    ###### 메모리 할당 ################
    outImage = [];    outImage = malloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    for i in range(inH) :
        for k in range(inW) :
            outImage[i][k] = 255 - inImage[i][k]
    display()

##################################################################

window = Tk() # tkinter.Tk()를 적용할 경우 가장 기본적인 윈도우 창이 생성됩니다.
window.geometry("500x500") # 윈도우이름.geometry("너비x높이+x좌표+y좌표") 초기 화면 위치의 x좌표와 y좌표를 설정
window.title("컴퓨터 비전(딥러닝 기법) ver 0.01")

mainMenu = Menu(window) # 해당 메뉴창에 표시할 상위 메뉴의 속성을 설정할 수 있습니다. 파라미터를 사용하여 상위 메뉴의 속성을 설정합니다.
window.config(menu=mainMenu) # 윈도우 창.config(menu=메뉴 이름)을 통하여 해당 윈도우 창에 메뉴를 등록할 수 있습니다.

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImage)
fileMenu.add_separator()
# add_cascade(파라미터)	상위 메뉴와 하위 메뉴 연결
# add_separator()	구분선 생성

comVisionMenu1 = Menu(mainMenu) # COMputerVision
mainMenu.add_cascade(label="화소점 처리", menu=comVisionMenu1) # 풍성하게 늘어진것
comVisionMenu1.add_command(label="반전", command=revImage)

window.mainloop()