a = int(input("숫자1 ->"))
b = int(input("숫자2->"))
result = a + b
print(a, "+", b, "=", result)
result= a - b
print(a, "-", b, "="result)
delattr(


)