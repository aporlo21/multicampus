#(1) p219. 16진수 정렬 --> 선택정렬, 버블정렬, 퀵정렬
import random

data = []
i,k = 0,0

## 메인 코드 부분
if __name__ == '__main__' :
    for i in range(0,10) :
        temp = hex(random.randint(0,100000))
        data.append(temp)

    print('정렬 전 데이터 : ', end =' ')
    [print(num, end = ' ') for num in data]

    for i in range(0,len(data)-1) :
        for k in range(i+1,len(data)) :
            if int(data[i],16) > int(data[k],16) :
                temp = data[i]
                data[i]=data[k]
                data[k]=temp

    print('\n정렬 후 데이터 : ',end=' ')
    [print(num, end = ' ') for num in data]
