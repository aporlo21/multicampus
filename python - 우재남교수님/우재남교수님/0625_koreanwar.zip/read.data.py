import csv

f = open('C:\BigData\mnist/train_1K.csv', 'r', encoding='utf-8')
rdr = csv.reader(f)
for line in rdr:
    print(line)
f.close()