from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time
import pandas as pd
import numpy as np
from sklearn import svm, metrics
from sklearn.model_selection import train_test_split
import joblib
from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time



def malloc(h, w, initValue=0, dataType=np.uint8):
    retMemory = np.zeros((h, w), dtype=dataType)
    retMemory += initValue
    return retMemory


# 차원 변환
def dimTrans(ndarray, Height, Width):
    newArray = (ndarray.reshape(Height * Width, 3).T).reshape(3, Height, Width)
    return newArray


def saveTrans(ndarray, Height, Width):
    newArray = ndarray.reshape(3, Height * Width)
    newArray = newArray.T
    newArray = newArray.reshape(Width, Height, 3)
    return newArray


# 파일을 메모리로 로딩하는 함수
def loadImageColor(fname_CVdata):
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    inImage = []
    ######################################
    # PIL 개체 -> OpenCV 개체로 복사
    if type(fname_CVdata) == str:  # 문자열 = 파일name으로 넘어온것
        cvData = cv2.imread(fname_CVdata)  # 파일 ->   CV데이터
    else:
        cvData = fname_CVdata  # 데이터로 취급

    cvPhoto = cv2.cvtColor(cvData, cv2.COLOR_BGR2RGB)
    photo = Image.fromarray(cvPhoto)
    inH, inW, channels = cvPhoto.shape
    inImage = dimTrans(cvPhoto, inH, inW)


# 파일을 선택해서 메모리로 로딩하는 함수

def openImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    filename = askopenfilename(parent=window,
                               filetypes=(("칼라 파일", "*.jpg;*.png;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if filename == '' or filename == None:
        return
    start = time.time()
    loadImageColor(filename)
    equalImageColor()
    displayImageColor()
    seconds = time.time() - start
    status.configure(text=status.cget("text") + "\t\t 시간(초):" + "{0:.2f}".format(seconds))


def saveImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    start = time.time()
    outArray = saveTrans(outImage, outH, outW)
    savePhoto = Image.fromarray(outArray.astype(np.uint8), 'RGB')
    saveFp = asksaveasfile(parent=window, mode='wb',
                           defaultextension='.', filetypes=(("그림 파일", "*.png;*.jpg;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None:
        return
    savePhoto.save(saveFp.name)
    seconds = time.time() - start
    status.configure(text=status.cget("text") + "\t\t 시간(초):" + "{0:.2f}".format(seconds))


def bwImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    outImage = [];
    outImage = malloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####

    # avg = np.mean(inImage)

    inImage = inImage.astype(np.int16)

    outImage = inImage

    # greyscale으로 변환
    # 메모리 확보
    grey = []
    for _ in range(3):
        grey.append(malloc(inH, inW))
    # greyscale
    for RGB in range(3):
        grey[RGB] = (inImage[R] + inImage[G] + inImage[B]) // 3
    # 평균
    avg = np.mean(grey).astype(np.int16)

    # 이진화
    outImage = np.where(grey > avg, 255, outImage)
    outImage = np.where(grey < avg, 0, outImage)

    outImage = outImage.astype(np.uint8)

    displayImageColor()


# 파라볼라 알고리즘 with LUT
def paraImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    outImage = inImage[:]
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    x = np.array([i for i in range(0, 256)])
    LUT = 255 - 255 * np.power(x / 128 - 1, 2)
    LUT = LUT.astype(np.uint8)
    outImage = LUT[inImage]
    displayImageColor()


# OpenCV용 컴퓨터 딥러닝
###############################################
def greydisplay():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global VIEW_X, VIEW_Y
    if canvas != None:  # 예전에 실행한 적이 있다.
        canvas.destroy()

    ## 고정된 화면 크기
    if outH <= VIEW_Y or outW <= VIEW_X:
        VIEW_X = outW
        VIEW_Y = outH
        step = 1
    else:
        VIEW_X = 512
        VIEW_Y = 512
        step = outW / VIEW_X

    window.geometry(str(int(VIEW_Y * 1.2)) + 'x' + str(int(VIEW_X * 1.2)))  # 벽
    canvas = Canvas(window, height=VIEW_Y, width=VIEW_X)
    paper = PhotoImage(height=VIEW_Y, width=VIEW_X)
    canvas.create_image((VIEW_Y // 2, VIEW_X // 2), image=paper, state='normal')

    rgbStr = ''  # 전체 픽셀의 문자열을 저장
    for i in np.arange(0, outH, step):
        tmpStr = ''
        for k in np.arange(0, outW, step):
            i = int(i);
            k = int(k)
            r = g = b = outImage[i][k]
            tmpStr += ' #%02x%02x%02x' % (r, g, b)
        rgbStr += '{' + tmpStr + '} '
    paper.put(rgbStr)

    canvas.bind('<Button-1>', mouseClick)
    canvas.bind('<ButtonRelease-1>', mouseDrop)
    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='이미지 정보:' + str(outW) + 'x' + str(outH))


def embossOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    mSize = askinteger("홀수값을 입력하시오", "마스크 크기")
    mask = np.zeros((mSize, mSize), np.float32)
    mask[0][0] = -1
    mask[mSize - 1][mSize - 1] = 1
    cvPhoto2 = cv2.filter2D(cvPhoto, -1, mask)
    cvPhoto2 += 127

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def greyScaleOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto

    ##### 알고리즘 #####
    outImage = cv2.cvtColor(cvPhoto, cv2.COLOR_RGB2GRAY)
    greydisplay()


def blurOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    mSize = askinteger("홀수값을 입력하시오", "마스크 크기")
    mask = np.ones((mSize, mSize), np.float32) / (mSize * mSize)
    cvPhoto2 = cv2.filter2D(cvPhoto, -1, mask)

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def rotateOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    angle = askinteger("회전", "각도")
    rotate_matrix = cv2.getRotationMatrix2D((outH // 2, outW // 2), angle, 1)  # 중앙점, 각도, scale(확대옵션)
    cvPhoto2 = cv2.warpAffine(cvPhoto, rotate_matrix, (outH, outW))

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def zoomOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    scale = askfloat("배율", "배율를 입력하시오")
    cvPhoto2 = cv2.resize(cvPhoto, None, fx=scale, fy=scale)

    outImage = dimTrans(cvPhoto2, int(inH * scale), int(inW * scale))

    channels, outH, outW = outImage.shape

    displayImageColor()


def waveHorOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    cvPhoto2 = np.zeros(cvPhoto.shape, dtype=cvPhoto.dtype)
    for i in range(inH):
        for k in range(inW):
            oy = int(15.0 * math.sin(2 * 3.14 * k / 180))
            ox = 0
            if i + oy < inH:
                cvPhoto2[i][k] = cvPhoto[(i + oy) % inH][k]
            else:
                cvPhoto2[i][k]

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def waveVirOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto
    ##### 알고리즘 #####
    cvPhoto2 = np.zeros(cvPhoto.shape, dtype=cvPhoto.dtype)
    for i in range(inH):
        for k in range(inW):
            ox = int(25.0 * math.sin(2 * 3.14 * i / 180))
            oy = 0
            if k + ox < inW:
                cvPhoto2[i][k] = cvPhoto[i][(k + ox) % inW]
            else:
                cvPhoto2[i][k]
    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def cartoonOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto

    ##### 알고리즘 #####
    baseColor = cv2.bilateralFilter(cvPhoto, 15, 125, 75)
    baseGrey = cv2.cvtColor(cvPhoto, cv2.COLOR_RGB2GRAY)
    baseGrey = cv2.medianBlur(baseGrey, 11)
    edges = cv2.Laplacian(baseGrey, cv2.CV_8U, ksize=5)
    ret, mask = cv2.threshold(edges, 100, 255, cv2.THRESH_BINARY_INV)
    baseEdge = cv2.cvtColor(mask, cv2.COLOR_GRAY2RGB)
    rawBase = np.ma.masked_equal(baseColor * baseEdge, 255)
    cvPhoto2 = baseEdge - rawBase

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()


def denoiseOpenCV():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, cvPhoto

    ##### 알고리즘 #####
    cvPhoto2 = cv2.bilateralFilter(cvPhoto, 15, 125, 75)

    outImage = dimTrans(cvPhoto2, outH, outW)

    displayImageColor()

< / pre >