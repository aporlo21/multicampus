import pymysql # id, id, pw, port, db 정보 필요한작업 대체
# DB 접속정보
IP = '192.168.56.112'
USER = 'root'
PW = '1234'
DB = 'quiz_db4'

# 03-09
conn = pymysql.connect(host=IP, user=USER, password=PW,
                       db=DB, charset="utf8")  # 1. DB 연결
cur = conn.cursor() # 다리연결
sql = "SELCET 아이디, 주민번호, 이메일 FROM quiz_tbl_4"
cur.execute(sql)

while True :
    rows = cur.fetchall()
    for row in rows :
        print(row[0], row[1], row[2]) # id, name, pay
# conn.commit() # 컴퓨터를 끄면 자동커밋이 된다
cur.close()
conn.close()

# quiz1) (quiz_db) (quiz_tbl: 아이디, 주민번호, 이메일) sql로 데이터 3건 입력하기
# quiz2) python에서 아이디 주민번호 이메일을 키보드로 입력받은후, 데이터베이스에서 저장하기 아이디를 그냥 엔터치면 그만입력
# quiz3) 퀴즈 2의 데이터를 조회해서 출력
    # 아이디 주민번호 이메일
    # ----------------------

