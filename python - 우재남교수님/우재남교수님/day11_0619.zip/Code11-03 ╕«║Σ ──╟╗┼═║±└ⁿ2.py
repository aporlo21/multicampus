from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import os
import os.path
import math
import numpy
import pymysql
import csv
import xlrd
import xlwt
import xlsxwriter

# def mallod(nmw)
#
# def loadimage(fname):
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     w-indow.geometry('500x500')
#     window,title("리뷰용 컴퓨터 비
#     canvas = Canvas(window, width = 500, height = 500)
#     paper = canvas.create_image(width = 500, height = 500)
#         # canvas.create_line(10, 10 ,100, 100, width = 5, fill = 'red')
#     outImage[i][k] = inImage[i][k]
#
# def addImage():
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ## 메모리 할당 ##
#     outImage = []
#     outImage = malloc(outH, outW)
#     ## 컴퓨터 비전 알고리즘 ##
#     for i in range(inH) :
#         for k in range(inW) :
#             outImage[i][k] = inImage[i][k] + 100
#     displayImage()
#
#
# canvas.pack(expand  = 1, anchor = CENTER)
# window.mainloop()
#
#
# mainMenu = Menu(window)
# window.config(menu=mainMenu)
#
# wintr
# fileMenu = Menu(mainMenu)
# mainMenu.add_cascade(label="파일", menu=fileMenu)
# fileMenu.add_command(label="파일 열기", command=openImage)
# fileMenu.add_separator()
# fileMenu.add_command(label="파일 저장", command=saveImage)
#
# comVisionMenu1 = Menu(mainMenu)
# mainMenu.add_cascade(label="화소점 처리", menu=comVisionMenu1)
# comVisionMenu1.add_command(label="덧셈/뺄셈", command=addImage)
#
#
# cvMenu = Menu(mainMenu)
# mainMenu.add_cascade(label)

# numpy on console
import numpy as np
# list = [ num for num in range(10, 100, 10)]
# list
# list2 = [ num for num in range(10, 100, 10)]
# list2
# A = np.array(list2)
# A
# A[3]
# myList = [[n for n in range(10,50,10) for _ in range(50,80)]]
# myList
# B = np.array(myList)
# B # matrix
# B + 100
# B
def malloc(h, w, dataYpe=np.uint8 ) : # 8비트 unsigned int
    retMemory = []
    retMemory = np.zeros((h, w), dtype=dataType)
    return retMemory

def equalImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW

    outH = inH
    outW = inW

    outImage = inImage[:]
    displayImage()

def addImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW

    outH = inH
    outW = inW

    outImage = inImage + 100
    displayImage()