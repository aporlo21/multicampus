from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
import numpy as np

def equalImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    outH = inH;
    outW = inW;
    outImage = inImage.copy()

    displayImage()


# 동일영상 알고리즘
def addImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    outImage = [];
    outImage = malloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    value = askinteger("밝게/어둡게", "값-->", minvalue=-255, maxvalue=255)

    start = time.time()
    inImage = inImage.astype(np.int16)

    outImage = inImage + value
    outImage = np.where(outImage > 255, 255, outImage)
    outImage = np.where(outImage < 0, 0, outImage)

    # 이터레이터 생성 (순회용)
    # iterator = np.nditer(outImage, flags=['multi_index'], op_flags=['readwrite'])

    # ** 이터레이터 기본 구문 # 훨씬 느리다.
    # while not iterator.finished:
    #    idx = iterator.multi_index
    #    if outImage[idx] > 255:
    #        outImage[idx] = 255
    #    elif outImage[idx] < 0:
    #        outImage[idx] = 0
    #   iterator.iternext()

    seconds = time.time() - start
    print("밝기 연산속도:", time.time() - start)
    displayImage()
    status.configure(text=status.cget("text") + "\t\t 시간(초):" + "{0:.2f}".format(seconds))


# 반전영상 알고리즘
def revImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    start = time.time()
    outImage = 255 - inImage
    print("반전 속도:", time.time() - start)
    displayImage()


# 이진화 알고리즘
def bwImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    start = time.time()

    avg = inImage.mean()
    print("T:", avg)
    outImage = np.where(inImage > avg, 255, 0)
    print("걸린시간:", time.time() - start)
    displayImage()


# 파라볼라 알고리즘 with LUT
def paraImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    start = time.time()

    LUT = (255 - 255 * (np.arange(256) / 128 - 1) * (np.arange(256) / 128 - 1))
    LUT = LUT.astype(np.uint8)

    outImage = LUT[inImage]
    print("걸린시간:", time.time() - start)

    displayImage()


# 상하반전 알고리즘
def upDownImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    start = time.time()
    outImage = inImage[:][::-1]

    print("걸린시간:", time.time() - start)
    displayImage()


# 화면이동 알고리즘
def moveImage():
    global panYN
    panYN = True
    canvas.configure(cursor='mouse')


def mouseClick(event):
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global sx, sy, ex, ey, panYN
    if panYN == False:
        return
    sx = event.x;
    sy = event.y


def mouseDrop(event):
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global sx, sy, ex, ey, panYN
    if panYN == False:
        return
    ex = event.x;
    ey = event.y
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;

    start = time.time()

    mx = sx - ex;
    my = sy - ey

    temp = np.zeros((3 * outH, 3 * outW), dtype=np.uint8)
    temp[outH:2 * outH, inW:2 * outW] = inImage
    outImage = temp[outH + my:2 * outH + my, outW + mx:2 * outW + mx]

    panYN = False
    print("걸린시간:", time.time() - start)
    displayImage()


# 영상 축소 알고리즘
def zoomOutImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("축소", "값-->", minvalue=2, maxvalue=16)
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH // scale;
    outW = inW // scale;
    start = time.time()

    outImage = inImage[::scale, ::scale]

    print("걸린시간:", time.time() - start)

    displayImage()


# 영상 축소 알고리즘 (평균변환)
def zoomOutImage2():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("축소", "값-->", minvalue=2, maxvalue=16)
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH // scale;
    outW = inW // scale;
    outImage = np.zeros((outH, outW), dtype=np.uint8)
    start = time.time()

    for r in range(0, inH - scale + 1, scale):
        for c in range(0, inW - scale + 1, scale):
            outImage[r // scale, c // scale] = inImage[r:r + scale, c:c + scale].mean()

    print("걸린시간:", time.time() - start)
    displayImage()


# 영상 확대 알고리즘
def zoomInImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("확대", "값-->", minvalue=2, maxvalue=8)
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH * scale;
    outW = inW * scale;
    outImage = np.zeros((outH, outW), dtype=np.uint8)
    start = time.time()

    outImage = inImage[::1 / scale, ::1 / scale]
    print("걸린시간:", time.time() - start)
    displayImage()