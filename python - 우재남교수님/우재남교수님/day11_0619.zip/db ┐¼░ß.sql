SHOW DATABASES;
CREATE DATABASE review_db;
USE review_db;
-- 직원테이블
CREATE TABLE emp_tbl (
	emp_id INT PRIMARY KEY,
    emp_name VARCHAR(5),
    emp_pay INT )
SHOW TABLES;
DESCRIBE emo_tbl;
INSERT INTO emp_tbl(emp_id, emp_name, emp_pay)
VALUES ( 10001, N'홍길동', 5000 );
SELECT * FROM emp_tbl