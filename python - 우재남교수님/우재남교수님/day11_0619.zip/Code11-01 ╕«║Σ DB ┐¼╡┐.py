import pymysql # id, id, pw, port, db 정보 필요한작업 대체
# DB 접속정보
IP = '192.168.56.111'
USER = 'root'
PW = '1234'
DB = 'review'

# 03-09

try :
    conn = pymysql.connect(host=IP, user=USER, password=PW,
                       db=DB, charset="utf8")  # 1. DB 연결
except :
    print('DB 연결 실패')
    exit()

cur = conn.cursor() # 다리연결

sql = "INSERT INTO emp_tbl(emp_id, emp_name, emp_pay)"
sql += " VALUES ( 10001, N'홍길동', 5000 )"

try :
    cur.execute(sql)
except :
    print('입력실패~~확인요망..')

conn.commit() # 컴퓨터를 끄면 자동커밋이 된다
cur.close()
conn.close()
