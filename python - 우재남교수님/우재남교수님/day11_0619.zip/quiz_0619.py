import pymysql
IP = '192.168.56.112'
USER = 'root'
PW = '1234'
DB = 'quiz_db4'

conn = pymysql.connect(host = IP, id = USER, password = PW, database = DB, charset = "utf8")
cur = conn.cursor()

sql = "CREATE TABLE IF NOT EXISTS quizTable2(userId INT, userName CHAR(5), userAge INT)"
cur.execute(sql)

sql = "INSERT INTO quizTable2 VALUES( 1 , '홍길동', 21)"
cur.execute(sql)
sql = "INSERT INTO quizTable2 VALUES( 2 , '이순신', 39)"
cur.execute(sql)

cur.close()
conn.commit()
conn.close()
print("created"

window.geometry
paper = PhotoImage(width = 500, height = 500)
canvas.create_image((500 // 2, 500 // 2), image=paper, state='normal')
