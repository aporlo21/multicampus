SHOW DATABASES;
CREATE DATABASE quiz_db4;
USE quiz_db4;
CREATE TABLE quiz_tbl_4 (
	아이디  VARCHAR(20), 
	주민번호 VARCHAR(20) PRIMARY KEY,
	이메일	VARCHAR(20) );
SHOW TABLES;
DESCRIBE quiz_tbl_4;
INSERT INTO quiz_tbl_4(아이디, 주민번호, 이메일)
VALUES(N'aporlo21', '940108-1111111', N'aporlo21@naver.com');

SELECT * FROM quiz_tbl_4;
















