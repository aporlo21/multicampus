from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time
import pandas as pd
import numpy as np
from sklearn import svm, metrics
from sklearn.model_selection import train_test_split
import joblib
from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time

# 파일을 선택해서 메모리로 로딩하는 함수
####################

# 메모리를 할당해서 리스트(참조)를 반환하는 함수
def malloc(h, w, initValue=0) :
    retMemory= []
    for _ in range(h) :
        tmpList = []
        for _ in range(w) :
            tmpList.append(initValue)
        retMemory.append(tmpList)
    return retMemory

# 파일을 메모리로 로딩하는 함수
def loadImageColor(fname) :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo, mouseImage
    inImage = []
    photo = Image.open(fname) # PIL 객체
    inW = photo.width; inH=photo.height
    ## 메모리 확보
    for _ in range(3) :
        inImage.append(malloc(inH, inW))

    photoRGB = photo.convert('RGB')
    for i in range(inH) :
        for k in range(inW) :
            r, g, b = photoRGB.getpixel((k,i))
            inImage[R][i][k] = r
            inImage[G][i][k] = g
            inImage[B][i][k] = b

def openImageColor() :
    global window, canvas, paper, filename, inImage, outImage,inH, inW, outH, outW, mouseImage
    filename = askopenfilename(parent=window,
                filetypes=(("칼라 파일", "*.jpg;*.png;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if filename == '' or filename == None :
        return
    loadImageColor(filename)
    equalImageColor()

    displayImageColor()

def displayImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW, mouseImage

    inImage = outImage[:]
    photo = outImage[:]

    if canvas != None : # 예전에 실행한 적이 있다.
        canvas.destroy()
    global VIEW_X, VIEW_Y
    # VIEW_X, VIEW_Y = 512, 512
    ## 고정된 화면 크기
    # 가로/세로 비율 계산

    if inW <= 512 and inH <= 512 : # 정방형 관계없이 둘다 512보다 작으면 그냥 사용
        VIEW_X = inH
        VIEW_Y = inW
    else : # 한쪽이라도 512보다 크면
        ratio = inH / inW
        if ratio < 1:
            VIEW_X = int(512 * ratio)
            if inW > 512 :
                VIEW_Y = 512
            else :
                VIEW_Y = inW
        elif ratio > 1:
            ratio = 1/ratio
            if inH > 512 :
                VIEW_X = 512
            else :
                VIEW_X = inH
            VIEW_Y = int(512 * ratio)
        else :
            if inH > 512:
                VIEW_X = 512
            else:
                VIEW_X = inH
            if inW > 512:
                VIEW_Y = 512
            else:
                VIEW_Y = inW

    if outH <= VIEW_X :
        stepX = 1
    if outH > VIEW_X :
        stepX = outH / VIEW_X

    if outW <= VIEW_Y:
         stepY = 1
    if outW > VIEW_Y:
        stepY = outW / VIEW_Y

    print(VIEW_X, VIEW_Y, stepX, stepY)

    window.geometry(str(int(VIEW_Y*1.2)) + 'x' + str(int(VIEW_X*1.2)))  # 벽
    canvas = Canvas(window, height=VIEW_X, width=VIEW_Y)
    paper = PhotoImage(height=VIEW_X, width=VIEW_Y)
    canvas.create_image((VIEW_Y // 2, VIEW_X // 2), image=paper, state='normal')

    import numpy
    rgbStr = '' # 전체 픽셀의 문자열을 저장
    for i in numpy.arange(0,outH, stepX) :
        tmpStr = ''
        for k in numpy.arange(0,outW, stepY) :
            i = int(i); k = int(k)
            r , g, b = outImage[R][i][k], outImage[G][i][k], outImage[B][i][k]
            tmpStr += ' #%02x%02x%02x' % (r,g,b)
        rgbStr += '{' + tmpStr + '} '
    paper.put(rgbStr)

    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='이미지 정보:' + str(outW) + 'x' + str(outH))

import numpy as np
def saveImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW, mouseImage
    if outImage == None :
        return
    outArray= []
    for i in range(outH) :
        tmpList = []
        for k in range(outW) :
            tup = tuple([outImage[R][i][k],outImage[G][i][k],outImage[B][i][k],])
            tmpList.append(tup)
        outArray.append(tmpList)

    outArray = np.array(outArray)
    savePhoto = Image.fromarray(outArray.astype(np.uint8), 'RGB')

    saveFp = asksaveasfile(parent=window, mode='wb',
                           defaultextension='.', filetypes=(("그림 파일", "*.png;*.jpg;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None:
        return
    savePhoto.save(saveFp.name)
    print('Save~')

###############################################
##### 컴퓨터 비전(영상처리) 알고리즘 함수 모음 #####
###############################################
# 동일영상 알고리즘
def  equalImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW, mouseImage
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;  outW = inW;
    ## 메모리 확보
    outImage = []
    for _ in range(3):
        outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    for RGB in range(3) :
        for i in range(inH) :
            for k in range(inW) :
                outImage[RGB][i][k] = inImage[RGB][i][k]
    #############################
    displayImageColor()


def addImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW, mouseImage
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;  outW = inW;
    ## 메모리 확보
    # outImage = []
    # for _ in range(3):
    #     outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    value = askinteger("밝게/어둡게", "값-->", minvalue=-255, maxvalue=255)
    for RGB in range(3) :
        for i in range(inH) :
            for k in range(inW) :
                if inImage[RGB][i][k] + value > 255 :
                    outImage[RGB][i][k] = 255
                elif inImage[RGB][i][k] + value < 0 :
                    outImage[RGB][i][k] = 0
                else :
                    outImage[RGB][i][k] = inImage[RGB][i][k] + value
    #############################
    displayImageColor()

def revImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW, mouseImage
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    # ## 메모리 확보
    # outImage = []
    # for _ in range(3):
    #     outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    for RGB in range(3):
        for i in range(inH):
            for k in range(inW):
                outImage[RGB][i][k] = 255 - inImage[RGB][i][k]
    #############################
    displayImageColor()

def leftMouseClick(event) :
    global sx, sy, ex, ey
    sx = event.x; sy = event.y

def changeValue(lst):
    return [float(v) / 255 for v in lst]

def studyCSV() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage
    ##0. 훈련데이터, 테스트데이터 준비
    filename = askopenfilename(parent=window,
        filetypes=(("CSV 파일", "*.csv"), ("모든 파일", "*.*")))
    if filename == None or filename == '' :
        return
    csv = pd.read_csv(filename)
    train_data = csv.iloc[:, 1:].values
    train_data = list(map(changeValue, train_data))
    train_label = csv.iloc[:, 0].values
    # 1. Classifire 생성(선택) --> 머신러닝 알고리즘 선택
    clf = svm.SVC(gamma='auto')
    # 2. 데이터로 학습 시키기
    clf.fit(train_data, train_label)
    status.configure(text='훈련 성공 ~~')

def studyDump() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage
    filename = askopenfilename(parent=window,
        filetypes=(("덤프 파일", "*.dmp"), ("모든 파일", "*.*")))
    if filename == None or filename == '' :
        return
    # 학습된 모델 저장하기
    clf = joblib.load(filename)
    status.configure(text='모델 로딩 성공 ~~')

def studySave() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage
    saveFp = asksaveasfile(parent=window, mode='wb',
            defaultextension='.', filetypes=(("덤프 파일", "*.dmp"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None:
        return
    # 학습된 모델 저장하기
    joblib.dump(clf,saveFp.name)
    status.configure(text='저장 성공 ~~~~')

def studyScore() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage
    if clf == None :
        return
    filename = askopenfilename(parent=window,
                               filetypes=(("CSV 파일", "*.csv"), ("모든 파일", "*.*")))
    if filename == None or filename == '':
        return
    csv = pd.read_csv(filename)
    test_data = csv.iloc[:, 1:].values
    test_data = list(map(changeValue, test_data))
    test_label = csv.iloc[:, 0].values
    result = clf.predict(test_data)
    score = metrics.accuracy_score(result, test_label)
    status.configure(text='정답률 : '+ "{0:.2f}%".format(score * 100))


def predictMouse():
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage
    if clf == None :
        status.configure(text='모델 먼저 생성하삼~~~')
        return

    mouseImage = malloc(280, 280)
    if canvas != None:
        canvas.delete()

    VIEW_X, VIEW_Y = 280, 280
    canvas = Canvas(window, height=VIEW_X, width=VIEW_Y, bg='black')
    # paper 대신 canvas 사용
    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='')
    ## 이벤트 바인드
    canvas.bind('<Button-3>', rightMouseClick)
    canvas.bind('<Button-2>', midClick)
    canvas.bind('<B3-Motion>', revMouseClick)
    canvas.bind('<Button-1>', leftMouseClick)
    canvas.bind('<B1-Motion>', leftMouseMove)
    canvas.bind('<ButtonRelease-1>', leftMouseDrop)
    canvas.configure(cursor='mouse')


def malloc(h, w, initValue=0) :
    retMemory= []
    for _ in range(h) :
        tmpList = []
        for _ in range(w) :
            tmpList.append(initValue)
        retMemory.append(tmpList)
    return retMemory

def rightMouseClick(event):
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage

    ## 280 --> 28 축소
    outImage = []
    outImage = malloc(28, 28)
    scale = 10
    for i in range(28):
        for k in range(28):
            outImage[i][k] = inImage[i * scale][k * scale]

    ## 2차원 --> 1차원
    my_data = []
    for i in range(28):
        for k in range(28):
            my_data.append(outImage[i][k])

    ## 출력해서
    for i in range(28 * 28):
        print("%2d" % my_data[i], end='')
        if i % 28 == 0:
            print()

    ## 예측하기
    result = clf.predict([my_data])  # 숫자 1개 # predict 메서드로 새로운 입력 데이터에 대한 출력 데이터 예측
    status.configure(text='예측 숫자1 ====> ' + str(result[0]))
    if (result == 1):
        openImageColor()
        revImageColor()

def midClick(event):
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper, mouseImage

    ## 280 --> 28 축소
    outImage = []
    outImage = malloc(28, 28)
    scale = 10
    for i in range(28):
        for k in range(28):
            outImage[i][k] = inImage[i * scale][k * scale]

    ## 2차원 --> 1차원
    my_data = []
    for i in range(28):
        for k in range(28):
            my_data.append(outImage[i][k])

    ## 출력해서
    for i in range(28 * 28):
        print("%2d" % my_data[i], end='')
        if i % 28 == 0:
            print()

    ## 예측하기
    result = clf.predict([my_data])  # 숫자 1개 # predict 메서드로 새로운 입력 데이터에 대한 출력 데이터 예측
    status.configure(text='예측 숫자2 ====> ' + str(result[0]))
    if (result == 3):

        addImageColor()

def revMouseClick(event) :
    global leftMousePressYN, mouseImage
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    canvas.delete('all')
    inImage = malloc(280,280)

leftMousePressYN = False
def leftMouseClick(event) :
    global  leftMousePressYN
    leftMousePressYN = True

def leftMouseMove(event) :
    global leftMousePressYN, mouseImage
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    if leftMousePressYN == False :
        return
    x = event.x; y = event.y
    canvas.create_oval(x-15, y-15, x+15, y+15, width=0, fill='white')
    # 주위 40x40개를 찍는다.
    for i in range(-15,15,1) :
        for k in range(-15,15,1) :
            if 0<= x+i < 280 and 0 <= y+k < 280 :
                inImage[y+k][x+i] = 1

def leftMouseDrop(event) :
    global leftMousePressYN
    leftMousePressYN = False

def clickButton1() :
    messagebox.showinfo('힌트문','안알랴쥼')

####################
#### 전역변수 선언부 ####
####################
R, G, B = 0, 1, 2
inImage, outImage = [], []  # 3차원 리스트(배열)
inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""
mouseImage = None
VIEW_X, VIEW_Y = 512, 512 # 화면에 보일 크기 (출력용)
# 머신러닝 관련 전역 변수
result, csv, train_data, train_label, test_data, test_label, clf = [None]*7

####################
#### 메인 코드부 ####
####################

window = Tk()
window.geometry("500x500")
window.title("숫자인식 영상처리 (MNIST) ver 0.01")

button1 = Button(window, text = '무엇이 궁금하십니까', command = clickButton1 )
button1.place(x=30, y=30)

label1 = Label(window, text = "'1 : 화소점처리' \n '2 : 학습시키기' \n ' 3 : 예측하기' \n 안내문 종료" )
label1.place(x=70, y=70)

button2 = Button(window, text = "인식할 수 입력", command = predictMouse)
button2.place(x=350, y=30)
# button2 = Button(window, text = '번호안내문', command = clickButton2 )
# button2.place(x=30, y=50)
button3 = Button(window, text = "모델 로딩", command = studyDump)
button3.place(x=225, y=30)


status = Label(window, text='', bd=1, relief=SUNKEN, anchor=W)
status.pack(side=BOTTOM, fill=X)

## 마우스 이벤트

mainMenu = Menu(window)
window.config(menu=mainMenu)

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImageColor)
fileMenu.add_separator()
fileMenu.add_command(label="파일 저장", command=saveImageColor)

comVisionMenu1 = Menu(mainMenu)
mainMenu.add_cascade(label="1", menu=comVisionMenu1)
comVisionMenu1.add_command(label="덧셈/뺄셈", command=addImageColor)
comVisionMenu1.add_command(label="반전하기", command=revImageColor)

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="2", menu=fileMenu)
fileMenu.add_command(label="CSV 파일로 새로 학습", command=studyCSV)
fileMenu.add_command(label="학습된 모델 가져오기", command=studyDump)
fileMenu.add_separator()
fileMenu.add_command(label="정답률 확인하기", command=studyScore)
fileMenu.add_separator()
fileMenu.add_command(label="학습모델 저장하기", command=studySave)

predictMenu = Menu(mainMenu)
mainMenu.add_cascade(label="3", menu=predictMenu)
predictMenu.add_separator()
predictMenu.add_command(label="마우스로 직접 쓰기", command=predictMouse)

window.mainloop()

#=========================================================================================


