from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time
import pandas as pd
import numpy as np
from sklearn import svm, metrics
from sklearn.model_selection import train_test_split
import joblib
from tkinter import *
from tkinter.simpledialog import *
from tkinter.filedialog import *
import math
import os
import os.path
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import time

# 파일을 선택해서 메모리로 로딩하는 함수
####################

# 메모리를 할당해서 리스트(참조)를 반환하는 함수
def malloc(h, w, initValue=0) :
    retMemory= []
    for _ in range(h) :
        tmpList = []
        for _ in range(w) :
            tmpList.append(initValue)
        retMemory.append(tmpList)
    return retMemory

# 파일을 메모리로 로딩하는 함수
def loadImageColor(fname) :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global photo
    inImage = []
    photo = Image.open(fname) # PIL 객체
    inW = photo.width; inH=photo.height
    ## 메모리 확보
    for _ in range(3) :
        inImage.append(malloc(inH, inW))

    photoRGB = photo.convert('RGB')
    for i in range(inH) :
        for k in range(inW) :
            r, g, b = photoRGB.getpixel((k,i))
            inImage[R][i][k] = r
            inImage[G][i][k] = g
            inImage[B][i][k] = b

def openImageColor() :
    global window, canvas, paper, filename, inImage, outImage,inH, inW, outH, outW
    filename = askopenfilename(parent=window,
                filetypes=(("칼라 파일", "*.jpg;*.png;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if filename == '' or filename == None :
        return
    loadImageColor(filename)
    equalImageColor()

    displayImageColor()

def displayImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW

    inImage = outImage[:]
    photo = outImage[:]

    if canvas != None : # 예전에 실행한 적이 있다.
        canvas.destroy()
    global VIEW_X, VIEW_Y
    # VIEW_X, VIEW_Y = 512, 512
    ## 고정된 화면 크기
    # 가로/세로 비율 계산

    if inW <= 512 and inH <= 512 : # 정방형 관계없이 둘다 512보다 작으면 그냥 사용
        VIEW_X = inH
        VIEW_Y = inW
    else : # 한쪽이라도 512보다 크면
        ratio = inH / inW
        if ratio < 1:
            VIEW_X = int(512 * ratio)
            if inW > 512 :
                VIEW_Y = 512
            else :
                VIEW_Y = inW
        elif ratio > 1:
            ratio = 1/ratio
            if inH > 512 :
                VIEW_X = 512
            else :
                VIEW_X = inH
            VIEW_Y = int(512 * ratio)
        else :
            if inH > 512:
                VIEW_X = 512
            else:
                VIEW_X = inH
            if inW > 512:
                VIEW_Y = 512
            else:
                VIEW_Y = inW

    if outH <= VIEW_X :
        stepX = 1
    if outH > VIEW_X :
        stepX = outH / VIEW_X

    if outW <= VIEW_Y:
         stepY = 1
    if outW > VIEW_Y:
        stepY = outW / VIEW_Y

    print(VIEW_X, VIEW_Y, stepX, stepY)

    window.geometry(str(int(VIEW_Y*1.2)) + 'x' + str(int(VIEW_X*1.2)))  # 벽
    canvas = Canvas(window, height=VIEW_X, width=VIEW_Y)
    paper = PhotoImage(height=VIEW_X, width=VIEW_Y)
    canvas.create_image((VIEW_Y // 2, VIEW_X // 2), image=paper, state='normal')

    import numpy
    rgbStr = '' # 전체 픽셀의 문자열을 저장
    for i in numpy.arange(0,outH, stepX) :
        tmpStr = ''
        for k in numpy.arange(0,outW, stepY) :
            i = int(i); k = int(k)
            r , g, b = outImage[R][i][k], outImage[G][i][k], outImage[B][i][k]
            tmpStr += ' #%02x%02x%02x' % (r,g,b)
        rgbStr += '{' + tmpStr + '} '
    paper.put(rgbStr)

    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='이미지 정보:' + str(outW) + 'x' + str(outH))

import numpy as np
def saveImageColor():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    if outImage == None :
        return
    outArray= []
    for i in range(outH) :
        tmpList = []
        for k in range(outW) :
            tup = tuple([outImage[R][i][k],outImage[G][i][k],outImage[B][i][k],])
            tmpList.append(tup)
        outArray.append(tmpList)

    outArray = np.array(outArray)
    savePhoto = Image.fromarray(outArray.astype(np.uint8), 'RGB')

    saveFp = asksaveasfile(parent=window, mode='wb',
                           defaultextension='.', filetypes=(("그림 파일", "*.png;*.jpg;*.bmp;*.tif"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None:
        return
    savePhoto.save(saveFp.name)
    print('Save~')

###############################################
##### 컴퓨터 비전(영상처리) 알고리즘 함수 모음 #####
###############################################
# 동일영상 알고리즘
def  equalImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;  outW = inW;
    ## 메모리 확보
    outImage = []
    for _ in range(3):
        outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    for RGB in range(3) :
        for i in range(inH) :
            for k in range(inW) :
                outImage[RGB][i][k] = inImage[RGB][i][k]
    #############################
    displayImageColor()


def addImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;  outW = inW;
    ## 메모리 확보
    outImage = []
    for _ in range(3):
        outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    value = askinteger("밝게/어둡게", "값-->", minvalue=-255, maxvalue=255)
    for RGB in range(3) :
        for i in range(inH) :
            for k in range(inW) :
                if inImage[RGB][i][k] + value > 255 :
                    outImage[RGB][i][k] = 255
                elif inImage[RGB][i][k] + value < 0 :
                    outImage[RGB][i][k] = 0
                else :
                    outImage[RGB][i][k] = inImage[RGB][i][k] + value
    #############################
    displayImageColor()

def revImageColor() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ## 메모리 확보
    outImage = []
    for _ in range(3):
        outImage.append(malloc(outH, outW))
    ############################
    ### 진짜 컴퓨터 비전 알고리즘 ###
    for RGB in range(3):
        for i in range(inH):
            for k in range(inW):
                outImage[RGB][i][k] = 255 - inImage[RGB][i][k]
    #############################
    displayImageColor()

# def paraImageColor() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ## 메모리 확보
#     outImage = []
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ############################
#     ### 진짜 컴퓨터 비전 알고리즘 ###\
#     LUT = [0 for _ in range(256)]
#     for input in range(256):
#         LUT[input] = int(255 - 255 * math.pow(input / 128 - 1, 2))
#
#     for RGB in range(3):
#         for i in range(inH):
#             for k in range(inW):
#                 outImage[RGB][i][k] = LUT[inImage[RGB][i][k]]
#     #############################
#     displayImageColor()

# def morphImageColor() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ## 추가 영상 선택
#     filename2 = askopenfilename(parent=window,
#                                filetypes=(("칼라 파일", "*.jpg;*.png;*.bmp;*.tif"), ("모든 파일", "*.*")))
#     if filename2 == '' or filename2 == None:
#         return
#     inImage2 = []
#     photo2 = Image.open(filename2) # PIL 객체
#     inW2 = photo2.width; inH2=photo2.height
#     ## 메모리 확보
#     for _ in range(3) :
#         inImage2.append(malloc(inH2, inW2))
#
#     photoRGB2 = photo2.convert('RGB')
#     for i in range(inH2) :
#         for k in range(inW2) :
#             r, g, b = photoRGB2.getpixel((k,i))
#             inImage2[R][i][k] = r
#             inImage2[G][i][k] = g
#             inImage2[B][i][k] = b
#
#     ## 메모리 확보
#     outImage = []
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#
#     # 작은 쪽에 맞춤
#     if inH > inH2 :
#         inH = inH2
#     if inW > inW2 :
#         inW = inW2
#     import threading
#     import time
#     def morpFunc():
#         w1 = 1;
#         w2 = 0
#         for _ in range(20):
#             for RGB in range(3) :
#                 for i in range(inH):
#                     for k in range(inW):
#                         newValue = int(inImage[RGB][i][k] * w1 + inImage2[RGB][i][k] * w2)
#                         if newValue > 255:
#                             newValue = 255
#                         elif newValue < 0:
#                             newValue = 0
#                         outImage[RGB][i][k] = newValue
#             displayImageColor()
#             w1 -= 0.05;
#             w2 += 0.05
#             time.sleep(0.5)
#
#     threading.Thread(target=morpFunc).start()
#
#
# # 상하반전 알고리즘
# def  upDownImageColor() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;  outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     for RGB in range(3) :
#         for i in range(inH) :
#             for k in range(inW) :
#                 outImage[RGB][inH-i-1][k] = inImage[RGB][i][k]
#
#     displayImageColor()
#
# # 영상 축소 알고리즘
# def  zoomOutImageColor() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     scale = askinteger("축소", "값-->", minvalue=2, maxvalue=16)
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH//scale;  outW = inW//scale;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     for RGB in range(3) :
#         for i in range(outH) :
#             for k in range(outW) :
#                 outImage[RGB][i][k] = inImage[RGB][i*scale][k*scale]
#
#     displayImageColor()
#
# # 영상 확대 알고리즘
# def  zoomInImageColor() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     scale = askinteger("확대", "값-->", minvalue=2, maxvalue=8)
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH*scale;  outW = inW*scale;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     for RGB in range(3) :
#         for i in range(outH) :
#             for k in range(outW) :
#                 outImage[RGB][i][k] = inImage[RGB][i//scale][k//scale]
#
#     displayImageColor()
#
#
# def  embossImageRGB() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;  outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     MSIZE = 3
#     mask = [ [-1, 0, 0],
#              [ 0, 0, 0],
#              [ 0, 0, 1] ]
#     ## 임시 입력영상 메모리 확보
#     tmpInImage, tmpOutImage=[], []
#     for _ in range(3):
#         tmpInImage.append(malloc(inH+MSIZE-1, inW+MSIZE-1, 127))
#     for _ in range(3):
#         tmpOutImage.append(malloc(outH, outW))
#     ## 원 입력 --> 임시 입력
#     for RGB in range(3) :
#         for i in range(inH) :
#             for k in range(inW) :
#                 tmpInImage[RGB][i+MSIZE//2][k+MSIZE//2] = inImage[RGB][i][k]
#     ## 회선연산
#     for RGB in range(3):
#         for i in range(MSIZE//2, inH + MSIZE//2) :
#             for k in range(MSIZE//2, inW + MSIZE//2) :
#                 # 각 점을 처리.
#                 S = 0.0
#                 for m in range(0, MSIZE) :
#                     for n in range(0, MSIZE) :
#                         S += mask[m][n]*tmpInImage[RGB][i+m-MSIZE//2][k+n-MSIZE//2]
#                 tmpOutImage[RGB][i-MSIZE//2][k-MSIZE//2] = S
#     ## 127 더하기 (선택)
#     for RGB in range(3):
#         for i in range(outH) :
#             for k in range(outW) :
#                 tmpOutImage[RGB][i][k] += 127
#     ## 임시 출력 --> 원 출력
#     for RGB in range(3):
#         for i in range(outH):
#             for k in range(outW):
#                 value = tmpOutImage[RGB][i][k]
#                 if value > 255 :
#                     value = 255
#                 elif value < 0 :
#                     value = 0
#                 outImage[RGB][i][k] = int(value)
#
#     displayImageColor()
#
# def  embossImagePillow() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global photo
#
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     photo2 = photo.copy()
#
#     photo2 = photo2.filter(ImageFilter.EMBOSS)
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#
#     ## 임시 출력 --> 원 출력
#     for i in range(outH):
#         for k in range(outW):
#             r, g, b = photo2.getpixel((k, i))
#             outImage[R][i][k] = r
#             outImage[G][i][k] = g
#             outImage[B][i][k] = b
#
#     displayImageColor()
#
# import colorsys
# sx, sy, ex, ey = [0] * 4
# def  embossImageHSV() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global sx, sy, ex, ey
#
#     ## 이벤트 바인드
#     canvas.bind('<Button-3>', rightMouseClick_embossImageHSV) # 이벤트실행 ("이벤트", 함수)
#     canvas.bind('<Button-1>', leftMouseClick)
#     canvas.bind('<B1-Motion>', leftMouseMove)
#     canvas.bind('<ButtonRelease-1>', leftMouseDrop_embossImageHSV)
#     canvas.configure(cursor='mouse')
#
#     displayImageColor()
#
# def leftMouseDrop_embossImageHSV(event) :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global sx, sy, ex, ey
#     ex = event.x;    ey = event.y
#     ##################
#     # 마우스 클릭을 어떤 방향이든지 인정
#     if sx > ex :
#         sx, ex = ex, sx
#     if sy > ey :
#         sy, ey = ey, sy
#
#     if outH > VIEW_X :
#         sx = int(sx * (inH / VIEW_X))
#         ex = int(ex * (inH / VIEW_X))
#
#     if outW > VIEW_Y :
#         sy = int(sy * (inW / VIEW_Y))
#         ey = int(ey * (inW / VIEW_Y))
#
#     __embossImageHSV()
#     ##################
#     canvas.unbind('<Button-3>')  #이벤트를 제거하는 메서드
#     canvas.unbind('<Button-1>')
#     canvas.unbind('<B1-Motion>')
#     canvas.unbind('<ButtonRelease-1>')
#
# boxLine = None
#
# def leftMouseMove(event) :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global sx, sy, ex, ey, boxLine
#     ex = event.x ; ey = event.y
#     if not boxLine :
#         pass
#     else :
#         canvas.delete(boxLine)
#     boxLine = canvas.create_rectangle(sx, sy, ex, ey, fill=None)

def leftMouseClick(event) :
    global sx, sy, ex, ey
    sx = event.x; sy = event.y

# def rightMouseClick_embossImageHSV(event) :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global sx, sy, ex, ey
#     sx = 0; sy = 0; ey = inH-1; ex = inW-1
#     ##################
#     __embossImageHSV()
#     ##################
#     canvas.unbind('<Button-3>')
#     canvas.unbind('<Button-1>')
#     canvas.unbind('<B1-Motion>')
#     canvas.unbind('<ButtonRelease-1>')

# def  __embossImageHSV() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 입력 RGB --> 입력 HSV
#     # 메모리 확보
#     inImageHSV = [];
#     for _ in range(3):
#         inImageHSV.append(malloc(inH, inW))
#     # RGB -> HSV
#     for i in range(inH) :
#         for k in range(inW) :
#             r, g, b = inImage[R][i][k], inImage[G][i][k], inImage[B][i][k]
#             h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
#             inImageHSV[0][i][k], inImageHSV[1][i][k], inImageHSV[2][i][k] = h, s, v
#
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     MSIZE = 3
#     mask = [[-1, 0, 0],
#             [0, 0, 0],
#             [0, 0, 1]]
#     ## 임시 입력영상 메모리 확보
#     tmpInImageV, tmpOutImageV = [], []
#     tmpInImageV=(malloc(inH + MSIZE - 1, inW + MSIZE - 1, 127))
#     tmpOutImageV=(malloc(outH, outW))
#     ## 원 입력 --> 임시 입력
#     for i in range(inH):
#         for k in range(inW):
#             tmpInImageV[i + MSIZE // 2][k + MSIZE // 2] = inImageHSV[2][i][k]
#     ## 회선연산
#     for i in range(MSIZE // 2, inH + MSIZE // 2):
#         for k in range(MSIZE // 2, inW + MSIZE // 2):
#             # 각 점을 처리.
#             S = 0.0
#             for m in range(0, MSIZE):
#                 for n in range(0, MSIZE):
#                     S += mask[m][n] * tmpInImageV[i + m - MSIZE // 2][k + n - MSIZE // 2]
#             tmpOutImageV[i - MSIZE // 2][k - MSIZE // 2] = S*255
#     ## 127 더하기 (선택)
#     for i in range(outH):
#         for k in range(outW):
#             tmpOutImageV[i][k] += 127
#             if tmpOutImageV[i][k] > 255 :
#                 tmpOutImageV[i][k] = 255
#             elif tmpOutImageV[i][k] < 0 :
#                 tmpOutImageV[i][k] = 0
#
#     ## HSV --> RGB
#     for i in range(outH):
#         for k in range(outW):
#             if sx <= k <= ex and sy <= i <= ey : # 범위에 포함되면
#                 h, s, v = inImageHSV[0][i][k], inImageHSV[1][i][k], tmpOutImageV[i][k]
#                 r, g, b = colorsys.hsv_to_rgb(h, s, v)
#                 outImage[R][i][k], outImage[G][i][k], outImage[B][i][k]= int(r), int(g), int(b)
#             else :
#                 outImage[R][i][k], outImage[G][i][k], outImage[B][i][k] = inImage[R][i][k], inImage[G][i][k], inImage[B][i][k]
#
#     displayImageColor()
#
#
# def  blurrImageRGB() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;  outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     MSIZE = 3
#     mask = [ [ 1/9, 1/9, 1/9],
#              [ 1/9, 1/9, 1/9],
#              [ 1/9, 1/9, 1/9] ]
#     ## 임시 입력영상 메모리 확보
#     tmpInImage, tmpOutImage=[], []
#     for _ in range(3):
#         tmpInImage.append(malloc(inH+MSIZE-1, inW+MSIZE-1, 127))
#     for _ in range(3):
#         tmpOutImage.append(malloc(outH, outW))
#     ## 원 입력 --> 임시 입력
#     for RGB in range(3) :
#         for i in range(inH) :
#             for k in range(inW) :
#                 tmpInImage[RGB][i+MSIZE//2][k+MSIZE//2] = inImage[RGB][i][k]
#     ## 회선연산
#     for RGB in range(3):
#         for i in range(MSIZE//2, inH + MSIZE//2) :
#             for k in range(MSIZE//2, inW + MSIZE//2) :
#                 # 각 점을 처리.
#                 S = 0.0
#                 for m in range(0, MSIZE) :
#                     for n in range(0, MSIZE) :
#                         S += mask[m][n]*tmpInImage[RGB][i+m-MSIZE//2][k+n-MSIZE//2]
#                 tmpOutImage[RGB][i-MSIZE//2][k-MSIZE//2] = S
#     ## 127 더하기 (선택)
#     # for RGB in range(3):
#     #     for i in range(outH) :
#     #         for k in range(outW) :
#     #             tmpOutImage[RGB][i][k] += 127
#     ## 임시 출력 --> 원 출력
#     for RGB in range(3):
#         for i in range(outH):
#             for k in range(outW):
#                 value = tmpOutImage[RGB][i][k]
#                 if value > 255 :
#                     value = 255
#                 elif value < 0 :
#                     value = 0
#                 outImage[RGB][i][k] = int(value)
#
#     displayImageColor()
#
# def  addSValuePillow() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     global photo
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     value = askfloat("","0~1~10")
#     photo2 = photo.copy()
#     photo2 = ImageEnhance.Color(photo2)
#     photo2 = photo2.enhance(value)
#
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#
#     ## 임시 출력 --> 원 출력
#     for i in range(outH):
#         for k in range(outW):
#             r, g, b = photo2.getpixel((k, i))
#             outImage[R][i][k] = r
#             outImage[G][i][k] = g
#             outImage[B][i][k] = b
#
#     displayImageColor()
#
# def  addSValueHSV() :
#     global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
#     ## 입력 RGB --> 입력 HSV
#     # 메모리 확보
#     inImageHSV = [];
#     for _ in range(3):
#         inImageHSV.append(malloc(inH, inW))
#     # RGB -> HSV
#     for i in range(inH):
#         for k in range(inW):
#             r, g, b = inImage[R][i][k], inImage[G][i][k], inImage[B][i][k]
#             h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
#             inImageHSV[0][i][k], inImageHSV[1][i][k], inImageHSV[2][i][k] = h, s, v
#
#     ## 중요! 코드. 출력영상 크기 결정 ##
#     outH = inH;
#     outW = inW;
#     ###### 메모리 할당 ################
#     outImage = [];
#     for _ in range(3):
#         outImage.append(malloc(outH, outW))
#     ####### 진짜 컴퓨터 비전 알고리즘 #####
#     value = askfloat("", "-255~255") # -255 ~ 255
#     value /= 255
#     ## HSV --> RGB
#     for i in range(outH):
#         for k in range(outW):
#             newS = inImageHSV[1][i][k] + value
#             if newS < 0 :
#                 newS = 0
#             elif newS > 1.0 :
#                 newS = 1.0
#             h, s, v = inImageHSV[0][i][k], newS, inImageHSV[2][i][k]*255
#             r, g, b = colorsys.hsv_to_rgb(h, s, v)
#             outImage[R][i][k], outImage[G][i][k], outImage[B][i][k] = int(r), int(g), int(b)
#
#     displayImageColor()

def changeValue(lst):
    return [float(v) / 255 for v in lst]

def studyCSV() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    ##0. 훈련데이터, 테스트데이터 준비
    filename = askopenfilename(parent=window,
        filetypes=(("CSV 파일", "*.csv"), ("모든 파일", "*.*")))
    if filename == None or filename == '' :
        return
    csv = pd.read_csv(filename)
    train_data = csv.iloc[:, 1:].values
    train_data = list(map(changeValue, train_data))
    train_label = csv.iloc[:, 0].values
    # 1. Classifire 생성(선택) --> 머신러닝 알고리즘 선택
    clf = svm.SVC(gamma='auto')
    # 2. 데이터로 학습 시키기
    clf.fit(train_data, train_label)
    status.configure(text='훈련 성공 ~~')

def studyDump() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    filename = askopenfilename(parent=window,
        filetypes=(("덤프 파일", "*.dmp"), ("모든 파일", "*.*")))
    if filename == None or filename == '' :
        return
    # 학습된 모델 저장하기
    clf = joblib.load(filename)
    status.configure(text='모델 로딩 성공 ~~')

def studySave() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    saveFp = asksaveasfile(parent=window, mode='wb',
            defaultextension='.', filetypes=(("덤프 파일", "*.dmp"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None:
        return
    # 학습된 모델 저장하기
    joblib.dump(clf,saveFp.name)
    status.configure(text='저장 성공 ~~~~')

def studyScore() :
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    if clf == None :
        return
    filename = askopenfilename(parent=window,
                               filetypes=(("CSV 파일", "*.csv"), ("모든 파일", "*.*")))
    if filename == None or filename == '':
        return
    csv = pd.read_csv(filename)
    test_data = csv.iloc[:, 1:].values
    test_data = list(map(changeValue, test_data))
    test_label = csv.iloc[:, 0].values
    result = clf.predict(test_data)
    score = metrics.accuracy_score(result, test_label)
    status.configure(text='정답률 : '+ "{0:.2f}%".format(score * 100))


def predictMouse():
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    if clf == None :
        status.configure(text='모델 먼저 생성하삼~~~')
        return

    inImage = malloc(280, 280)
    if canvas != None:
        canvas.delete()

    VIEW_X, VIEW_Y = 280, 280
    canvas = Canvas(window, height=VIEW_X, width=VIEW_Y, bg='black')
    # paper 대신 canvas 사용
    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='')
    ## 이벤트 바인드
    canvas.bind('<Button-3>', rightMouseClick)
    canvas.bind('<Button-2>', BackClick)
    canvas.bind('<B3-Motion>', midMouseClick)
    canvas.bind('<Button-1>', leftMouseClick)
    canvas.bind('<B1-Motion>', leftMouseMove)
    canvas.bind('<ButtonRelease-1>', leftMouseDrop)
    canvas.configure(cursor='mouse')



def malloc(h, w, initValue=0) :
    retMemory= []
    for _ in range(h) :
        tmpList = []
        for _ in range(w) :
            tmpList.append(initValue)
        retMemory.append(tmpList)
    return retMemory

def rightMouseClick(event):
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper

    ## 280 --> 28 축소
    outImage = []
    outImage = malloc(28, 28)
    scale = 10
    for i in range(28):
        for k in range(28):
            outImage[i][k] = inImage[i * scale][k * scale]

    ## 2차원 --> 1차원
    my_data = []
    for i in range(28):
        for k in range(28):
            my_data.append(outImage[i][k])

    ## 출력해서
    for i in range(28 * 28):
        print("%2d" % my_data[i], end='')
        if i % 28 == 0:
            print()

    ## 예측하기
    result = clf.predict([my_data])  # 숫자 1개 # predict 메서드로 새로운 입력 데이터에 대한 출력 데이터 예측
    status.configure(text='예측 숫자1 ====> ' + str(result[0]))
    # n1 = result1[0]
    # s1 = "n1"
    if (result == 1):
        openImageColor()
        revImageColor()

def BackClick(event):
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper

    ## 280 --> 28 축소
    outImage = []
    outImage = malloc(28, 28)
    scale = 10
    for i in range(28):
        for k in range(28):
            outImage[i][k] = inImage[i * scale][k * scale]

    ## 2차원 --> 1차원
    my_data = []
    for i in range(28):
        for k in range(28):
            my_data.append(outImage[i][k])

    ## 출력해서
    for i in range(28 * 28):
        print("%2d" % my_data[i], end='')
        if i % 28 == 0:
            print()

    ## 예측하기
    result = clf.predict([my_data])  # 숫자 1개 # predict 메서드로 새로운 입력 데이터에 대한 출력 데이터 예측
    status.configure(text='예측 숫자2 ====> ' + str(result[0]))
    # n1 = result1[0]
    # s1 = "n1"
    if (result == 2):
        openImageColor()
        addImageColor()

def midMouseClick(event) :
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    canvas.delete('all')
    inImage = malloc(280,280)

leftMousePressYN = False
def leftMouseClick(event) :
    global  leftMousePressYN
    leftMousePressYN = True

def leftMouseMove(event) :
    global leftMousePressYN
    global csv, train_data, train_label, test_data, test_label, clf
    global inImage, outImage, inH, inW, outH, outW, window, canvas, paper
    if leftMousePressYN == False :
        return
    x = event.x; y = event.y
    canvas.create_oval(x-15, y-15, x+15, y+15, width=0, fill='white')
    # 주위 40x40개를 찍는다.
    for i in range(-15,15,1) :
        for k in range(-15,15,1) :
            if 0<= x+i < 280 and 0 <= y+k < 280 :
                inImage[y+k][x+i] = 1

def leftMouseDrop(event) :
    global leftMousePressYN
    leftMousePressYN = False

def clickButton1() :
    messagebox.showinfo('힌트문','안알랴쥼')

####################
#### 전역변수 선언부 ####
####################
R, G, B = 0, 1, 2
inImage, outImage = [], []  # 3차원 리스트(배열)
inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""
VIEW_X, VIEW_Y = 512, 512 # 화면에 보일 크기 (출력용)
# 머신러닝 관련 전역 변수
result, csv, train_data, train_label, test_data, test_label, clf = [None]*7

####################
#### 메인 코드부 ####
####################

window = Tk()
window.geometry("500x500")
window.title("숫자인식 영상처리 (MNIST) ver 0.01")

button1 = Button(window, text = '무엇이 궁금하십니까', command = clickButton1 )
button1.place(x=30, y=30)

label1 = Label(window, text = "'1 : 파라볼라' \n '2 : 엠보싱' \n ' 3 : 기하학처리' \n 안내문 종료" )
label1.place(x=70, y=70)
# button2 = Button(window, text = '번호안내문', command = clickButton2 )
# button2.place(x=30, y=50)

status = Label(window, text='', bd=1, relief=SUNKEN, anchor=W)
status.pack(side=BOTTOM, fill=X)

## 마우스 이벤트

mainMenu = Menu(window)
window.config(menu=mainMenu)

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImageColor)
fileMenu.add_separator()
fileMenu.add_command(label="파일 저장", command=saveImageColor)

comVisionMenu1 = Menu(mainMenu)
mainMenu.add_cascade(label="화소점 처리", menu=comVisionMenu1)
comVisionMenu1.add_command(label="덧셈/뺄셈", command=addImageColor)
comVisionMenu1.add_command(label="반전하기", command=revImageColor)
# comVisionMenu1.add_command(label="파라볼라", command=paraImageColor)
# comVisionMenu1.add_separator()
# comVisionMenu1.add_command(label="모핑", command=morphImageColor)
# comVisionMenu1.add_separator()
# comVisionMenu1.add_command(label="채도조절(Pillow)", command=addSValuePillow)
# comVisionMenu1.add_command(label="채도조절(HSV)", command=addSValueHSV)
#
# comVisionMenu3 = Menu(mainMenu)
# mainMenu.add_cascade(label="기하학 처리", menu=comVisionMenu3)
# comVisionMenu3.add_command(label="상하반전", command=upDownImageColor)
# comVisionMenu3.add_command(label="축소", command=zoomOutImageColor)
# comVisionMenu3.add_command(label="확대", command=zoomInImageColor)
#
# comVisionMenu4 = Menu(mainMenu)
# mainMenu.add_cascade(label="화소영역 처리", menu=comVisionMenu4)
# comVisionMenu4.add_command(label="엠보싱(RGB)", command=embossImageRGB)
# comVisionMenu4.add_command(label="엠보싱(Pillow제공)", command=embossImagePillow)
# comVisionMenu4.add_command(label="엠보싱(HSV)", command=embossImageHSV)
# comVisionMenu4.add_separator()
# comVisionMenu4.add_command(label="블러링(RGB)", command=blurrImageRGB)

## 마우스 이벤트

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="학습 시키기", menu=fileMenu)
fileMenu.add_command(label="CSV 파일로 새로 학습", command=studyCSV)
fileMenu.add_command(label="학습된 모델 가져오기", command=studyDump)
fileMenu.add_separator()
fileMenu.add_command(label="정답률 확인하기", command=studyScore)
fileMenu.add_separator()
fileMenu.add_command(label="학습모델 저장하기", command=studySave)

predictMenu = Menu(mainMenu)
mainMenu.add_cascade(label="예측하기", menu=predictMenu)
predictMenu.add_separator()
predictMenu.add_command(label="마우스로 직접 쓰기", command=predictMouse)

window.mainloop()



#=========================================================================================


