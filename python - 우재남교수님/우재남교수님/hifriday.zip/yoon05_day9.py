from tkinter import * # Window 창을 생성할 수 있습니다.
from tkinter.simpledialog import * # 기본 대화 상자와 편리 함수.
from tkinter.filedialog import * # 사용자가 열거나 저장할 파일을 지정할 수 있도록 하는 일반 대화 상자입니다.
import math # 좀더 복잡한 연산 필요시
import os # 운영체제에서 제공되는 여러 기능 수행
import os.path #  os.path는 파일 경로를 생성 및 수정하고, 파일 정보를 쉽게 다룰 수 있게 해주는 모듈.

# 메뉴 선택 / 이미지 출력

inImage, outImage = [], []
inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""


# 파일을 선택해서 메모리로 로딩하는 함수
def openImage() :
    global window, canvas, paper,filename, inImage, outImage, inH, inW, outH, outW
    filename = askopenfilename(parent = window,
                               filetypes = ((" RAW파일", "*.raw"), ("모든 파일", "*.*")))
    loadImage(filename)
    equalImage()

# 파일을 메모리로 로딩하는 함수
def loadImage(fname) :

    global window, canvas, paper,\
        filename, inImage, outImage, inH, inW, outH, outW
    fsize = os.path.getsize(fname)
    inH = inW = int(math.sqrt(fsize))

    ## 입력영상 메모리 확보
    inImage = []
    inImage = memoryAlloc(inH, inW)

    ## 파일 ==> 메모리
    with open(filename, 'rb') as rFp :
        for i in range(inH) :
            for k in range(inW) :
                inImage[i][k] = int(ord(rFp.read(1)))

# ord : 하나의 유니코드 문자를 나타내는 문자열이 주어지면 해당 문자의 유니코드 코드 포인트를 나타내는 정수를 돌려줌
# open()함수로 파일을 열고
# 리턴되는 디스크립터를 rFp라는 이름에 바인딩(속성에 연관시킨다)한다 // 이후 들여쓴 블럭 내에서 rFp는 파일 핸들러 기능을 한다
# open함수내에 read / write / close 기능이 자동 내장되어 있다. <= with구문에 사용될수 있는 객체

# 메모리 할당해서 리스트를 반환하는 함수
def memoryAlloc(Height, Width) :

    retMemory = []
    for i in range(Height) :
        tmpList = []
        for k in range(Width) :
            tmpList.append(0)
        retMemory.append(tmpList)
    return retMemory

def equalImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드, 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴퓨터 비전 알고리즘 ##
    for i in range(outH) :
        for k in range(outW) :
            outImage[i][k] = inImage[i][k]
    displayImage()

def displayImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    if canvas != None :
        canvas.destroy()

    ## 화면 크기를 조절
    window.geometry(str(outH) + 'x' + str(outW))
    canvas = Canvas(window, height=outH, width=outW)
    paper = PhotoImage(height=outH, width=outW)
    canvas.create_image((outH//2, outW//2), image=paper, state='normal')

    # ## 출력영상 ==> 화면에 한점씩 찍자.
    # for i in range(outH) :
    #     for k in range(outW) :
    #         r = g = b = outImage[i][k]
    #         paper.put("#%02x%02x%02x" % (r, g, b), (k, i))
    # canvas.pack(expand = 1, anchor = CENTER)

    # 성능 개선
    rgbStr = '' # 전체 픽셀의 문자열을 저장
    for i in range(outW) :
        tmpStr = ''
        for k in range(outW) :
            r = g = b = outImage[i][k]
            tmpStr += ' #%02x%02x%02x' % (r,g,b)
        rgbStr += '{' + tmpStr + '} '
    paper.put(rgbStr)

    canvas.bind('<Button-1>', mouseClick) ## 위젯.bind("이벤트", 함수) => 위젯이벤트 작동시 실행할 함수설정
    canvas.bind('<ButtonRelease-1>', mouseDrop) ## 마우스왼쪽 버튼누르는 이벤트 당시 mouseDrop함수 작동
    canvas.pack(expand=1, anchor=CENTER) ## 미사용공간확보(모든공백채우기), 할당된공간내에서 위치지정(기본값)

import struct
def saveImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    saveFp = asksaveasfile(parent = window, mode = 'wb',
        defaultextension = '*.raw', filetypes = (("RAW파일", "*.raw"), ("모든 파일", "*.*")))
    if saveFp == '' or saveFp == None :
        return
    for i in range(outH) :
        for k in range(outW) :
            saveFp.write(struct.pack('8', outImage[i][k]))

    saveFp.close()


########## 진짜 컴퓨터비전 알고리즘 #######

def addImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    val = askinteger("밝게/어둡게", "값-->", minvalue=-255, maxvalue=255)
    for i in range(inH) :
        for k in range(inW) :
            value = inImage[i][k] + val
            if value > 255 :
                value = 255 # 흰색
            elif value < 0 :
                value = 0 # 검은색
            outImage[i][k] = value
    displayImage()

def revImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    for i in range(inH) :
        for k in range(inW) :
            outImage[i][k] = 255 - inImage[i][k]
    displayImage()

def bwImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    sum = 0
    for i in range(inH) :
        for k in range(inW) :
            sum += inImage[i][k]
    avg = sum // (inW * inH)

    for i in range(inH) :
        for k in range(inW) :
            if inImage[i][k] > avg :
                outImage[i][k] = 255
            else :
                outImage[i][k] = 0
    displayImage()

def paraImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드, 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 진짜 컴퓨터 비전 알고리즘 ##
    LUT = [0 for _ in range(256)]
    for input in range(256) :
        LUT[input] = int(255 - 255 * math.pow(input/128 -1, 2)) # pow : 제곱

    for i in range(inH) :
        for k in range(inH):
            input = inImage[i][k]
            outImage[i][k] = LUT[inImage[i][k]]
    displayImage()

def updownImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 출력 영상 크기 결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    for i in range(inH) :
        for k in range(inW) :
            outImage[inH-1-i][k] = inImage[i][k]
    displayImage()

#--------------------------------------------------------------------------------
# 화면이동 알고리즘
def moveImage() :
    global panYN
    panYN = True
    canvas.configure(cursor = 'mouse')

def mouseClick(event) :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global sx,sy,ex,ey, panYN # start # end
    if panYN == False :
        return
    sx = event.x # else : 실행
    sy = event.y

def mouseDrop(event) :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    global sx, sy, ex, ey, panYN
    if panYN == False:
        return

    ex = event.x # end x = event x축 좌표, y축 좌표
    ey = event.y

    ## 출력영상크기결정 ##
    outH = inH
    outW = inW
    ## 메모리 할당 ##
    outImage = [];
    outImage = memoryAlloc(outH, outW)
    ## 컴비 알고리즘 ##
    mx = sx - ex # mouse x축 좌표 = event 의 start & end x축 좌표
    my = sy - ey
    for i in range(inH) :
        for k in range(inW) :
            if 0 <= i - my < outW \
                    and 0 <= k - mx < outH :
                outImage[i-my][k-mx] = inImage[i][k]
    panYN = False
    displayImage()

#__________________________________________________________________________
# 기하학처리 알고리즘

def zoomOutImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("축소","값--->", minvalue=2, maxvalue=16)
    ## 중요, 출력영상크기 결정 ##
    outH = inH//scale # scale 배 축소
    outW = inW//scale
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    for i in range(outH) :
        for k in range(outW) :
            outImage[i][k] = inImage[i*scale][k*scale]
    displayImage()

def zoomOutImage1() : # 평균변환
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("축소","값--->", minvalue=2, maxvalue=16)
    outH = inH//scale
    outW = inW//scale
    outImage = []
    outImage = memoryAlloc(outH, outW)
    for i in range(inH) :
        for k in range(inW) :
            outImage[i//scale][k//scale] += inImage[i][k]
            # outImage (inH // 축소 배수 | inW // 확대배수 = outImage + inImage )
    for i in range(outH) :
        for k in range(outW) :
            outImage[i][k] //= (scale*scale)
    displayImage()

def zoomInImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("확대","값--->", minvalue=2, maxvalue=8)
    ## 중요, 출력영상크기 결정 ##
    outH = inH * scale # scale 배 축소
    outW = inW * scale
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    for i in range(outH) :
        for k in range(outW) :
            outImage[i][k] = inImage[i//scale][k//scale]
    displayImage()

def zoomInImage1() : # 양선형 보간
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    scale = askinteger("확대", "값--->", minvalue=2, maxvalue=8)
    ## 중요, 출력영상크기 결정 ##
    outH = inH * scale # scale 배 축소
    outW = inW * scale
    ## 메모리 할당 ##
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ## 컴 비 알고리즘 ##
    rH, rW, iH, iW = [0] * 4
    x,y = 0, 0
    c1, c2, c3, c4 = [0] * 4
    for i in range(outH):
        for k in range(outW):
            rH = i / scale
            rW = k / scale
            iH = int(rH)
            iW = int(rW)
            x = rW - iW
            y = rH - iH
            if 0 <= iH < inH-1 and 0 <= iW < inW-1 :
                c1 = inImage[iH][iW]
                c2 = inImage[iH][iW+1]
                c3 = inImage[iH+1][iW+1]
                c4 = inImage[iH+1][iW]
                newValue = c1*(1-y)*(1-x) + c2*(1-y)*x + c3*y*x + c4*y*x + c4*y*(1-x)
                outImage[i][k] = int(newValue)

    displayImage()

def rotateImage():
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    angle = askinteger("회전", "값-->", minvalue=1, maxvalue=360)
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ###### 메모리 할당 ################
    outImage = [];
    outImage = memoryAlloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    radian = angle * math.pi / 180
    for i in range(inH) :
        for k in range(inW):
            xs = i
            ys = k
            xd = int(math.cos(radian) * xs - math.sin(radian) * ys)
            yd = int(math.cos(radian) * xs + math.sin(radian) * ys)
            if 0 <= xd < inH and 0 <= yd < inW :
                outImage[xd][yd] = inImage[i][k]
    displayImage()

def rotateImage1 () :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    angle = askinteger("회전", "값-->", minvalue=1, maxvalue=360)
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ###### 메모리 할당 ################
    outImage = [];
    outImage = memoryAlloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    radian = angle * math.pi / 180
    cx = outW//2
    cy = outH//2

    for i in range(inH) :
        for k in range(inW) :
            xs = i
            ys = k
            xd = int(math.cos(radian) * (xs-cx) - math.sin(radian) * (ys-cy))
            yd = int(math.cos(radian) * (xs-cx) + math.sin(radian) * (ys-cy))
            if 0 <= xd < outH and 0 <= yd < outW :
                outImage[i][k] = inImage[i][k]
    displayImage()

#################################################################################3
# 히스토그램
import matplotlib.pyplot as plt

def histoImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    inCountList = [0] * 256
    outCountList = [0] * 256

    for i in range(inH) :
        for k in range(inW) :
            inCountList[inImage[i][k]] += 1

    for i in range(outH) :
        for k in range(outW) :
            outCountList[outImage[i][k]] += 1

    plt.plot(inCountList)
    plt.plot(outCountList)
    plt.show()

def stretchImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH
    outW = inW
    ###### 메모리 할당 ################
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    maxVal = minVal = inImage[0][0]
    for i in range(inH) :
        for k in range(inW):
            if inImage[i][k] < minVal :
                minVal = inImage[i][k]
            elif inImage[i][k] > maxVal :
                maxVal = inImage[i][k]
    for i in range(inH) :
        for k in range(inW) :
            outImage[i][k] = int(((inImage[i][k] - minVal) / (maxVal - minVal)) * 255)
    displayImage()
# 흑백시 대비가 확연하지 않으므로 히스토그램으로 확인이 가능하다 .

def endinImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####
    maxVal = minVal = inImage[0][0]
    for i in range(inH) :
        for k in range(inW) :
            if inImage[i][k] < minVal :
                minVal = inImage[i][k]
            elif inImage[i][k] > maxVal :
                maxVal = inImage[i][k]

    minAdd = askinteger("최소", "최소에서 추가==>", minvalue = 0, maxvalue = 255)
    maxAdd = askinteger("최대", "최대에서 추가==>", minvalue = 0, maxvalue = 255)

    minVal += minAdd
    maxVal -= maxAdd

    for i in range(inH) :
        for k in range(inW) :
            value = int(((inImage[i][k] - minVal) / (maxVal - minVal)) * 255)
            if value < 0 :
                value = 0
            elif value > 255 :
                value = 255
            outImage[i][k] = value
    displayImage()
# 어중간한 샋상을 범위에 따라 단순구분하여 색의 명확성을 높임

def equalizeImage() :
    global window, canvas, paper, filename, inImage, outImage, inH, inW, outH, outW
    ## 중요! 코드. 출력영상 크기 결정 ##
    outH = inH;
    outW = inW;
    ###### 메모리 할당 ################
    outImage = []
    outImage = memoryAlloc(outH, outW)
    ####### 진짜 컴퓨터 비전 알고리즘 #####














#####################################################
############### 전역변수 선언부 #####################
#####################################################
inImage, outImage = [], [] ; inH, inW, outH, outW = [0] * 4
window, canvas, paper = None, None, None
filename = ""
panYN = False
sx,sy,ex,ey = [0] * 4

##############################################################################

window = Tk() # tkinter.Tk()를 적용할 경우 가장 기본적인 윈도우 창이 생성됩니다.
window.geometry("500x500") # 윈도우이름.geometry("너비x높이+x좌표+y좌표") 초기 화면 위치의 x좌표와 y좌표를 설정
window.title("컴퓨터 비전(딥러닝 기법) ver 0.01")

mainMenu = Menu(window) # 해당 메뉴창에 표시할 상위 메뉴의 속성을 설정할 수 있습니다. 파라미터를 사용하여 상위 메뉴의 속성을 설정합니다.
window.config(menu=mainMenu) # 윈도우 창.config(menu=메뉴 이름)을 통하여 해당 윈도우 창에 메뉴를 등록할 수 있습니다.

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="파일", menu=fileMenu)
fileMenu.add_command(label="파일 열기", command=openImage)
fileMenu.add_separator()
fileMenu.add_command(label="파일 저장", command=saveImage)
# add_cascade(파라미터)	상위 메뉴와 하위 메뉴 연결
# add_separator()	구분선 생성

comVisionMenu1 = Menu(mainMenu) # COMputerVision
mainMenu.add_cascade(label="화소점 처리", menu=comVisionMenu1) # 풍성하게 늘어진것
comVisionMenu1.add_command(label="덧셈/뺄셈", command=addImage)
comVisionMenu1.add_command(label="반전", command=revImage)
comVisionMenu1.add_command(label="파라볼라", command=paraImage)
comVisionMenu1.add_separator()

comVisionMenu2 = Menu(mainMenu)
mainMenu.add_cascade(label="통계", menu=comVisionMenu2)
comVisionMenu2.add_command(label="이진화", command=bwImage)
comVisionMenu2.add_separator()
comVisionMenu2.add_command(label="히스토그램", command=histoImage)
comVisionMenu2.add_command(label="명암대비", command=stretchImage)
comVisionMenu2.add_command(label="End-In탐색", command=endinImage)
comVisionMenu2.add_command(label="평활화", command=equalizeImage)

comVisionMenu3 = Menu(mainMenu)
mainMenu.add_cascade(label="기하학 처리", menu=comVisionMenu3)
comVisionMenu3.add_command(label="상하반전", command=updownImage)
comVisionMenu3.add_command(label="이동", command=moveImage)
comVisionMenu3.add_command(label="축소", command=zoomOutImage)
comVisionMenu3.add_command(label="축소1", command=zoomOutImage1)
comVisionMenu3.add_command(label="확대", command=zoomInImage)
comVisionMenu3.add_command(label="확대1", command=zoomInImage1)
comVisionMenu3.add_command(label="회전", command=rotateImage)
comVisionMenu3.add_command(label="회전1", command=rotateImage1)

window.mainloop()